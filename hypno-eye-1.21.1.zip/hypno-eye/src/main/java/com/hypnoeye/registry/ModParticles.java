package com.hypnoeye.registry;

import com.hypnoeye.HypnoEye;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(BuiltInRegistries.PARTICLE_TYPE, HypnoEye.MODID);

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> HYPNO_RING =
            PARTICLES.register("hypno_ring", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
