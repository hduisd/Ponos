package com.hypnoeye.server;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.hypnoeye.HypnoConfig;
import com.hypnoeye.network.AnimPayload;
import com.hypnoeye.registry.ModEffects;
import com.hypnoeye.registry.ModItems;
import com.hypnoeye.registry.ModParticles;
import com.hypnoeye.registry.ModSounds;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server-authoritative part: the client only asks, the server checks item, cooldown, range, walls and target rules. */
public final class HypnosisLogic {
    private static final int MISS_COOLDOWN_TICKS = 20;

    public static void tryActivate(ServerPlayer player) {
        ItemStack head = player.getItemBySlot(EquipmentSlot.HEAD);
        if (!head.is(ModItems.HYPNO_EYE.get()) || player.isSpectator() || !player.isAlive()) {
            return;
        }
        if (player.getCooldowns().isOnCooldown(head.getItem())) {
            return;
        }
        ServerLevel level = player.serverLevel();

        List<LivingEntity> targets = findTargets(player, level);

        int cooldown = targets.isEmpty() ? MISS_COOLDOWN_TICKS : (int) Math.round(HypnoConfig.COOLDOWN_SECONDS.get() * 20.0);
        if (cooldown > 0) {
            player.getCooldowns().addCooldown(head.getItem(), cooldown);
        }

        // animation + sound for everyone who can see the caster
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new AnimPayload(player.getId()));
        level.playSound(null, player.getX(), player.getEyeY(), player.getZ(), ModSounds.ACTIVATE.get(), SoundSource.PLAYERS, 1.0F, 1.0F);

        if (targets.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.hypnoeye.no_target"), true);
            return;
        }

        int durationTicks = HypnoConfig.DURATION_SECONDS.get() * 20;
        Vec3 beamStart = player.getEyePosition().add(player.getViewVector(1.0F).scale(0.7)).add(0, -0.25, 0);
        LivingEntity last = null;
        for (LivingEntity target : targets) {
            // same amplifier => the timer is only reset to durationTicks, never summed
            MobEffectInstance instance = new MobEffectInstance(ModEffects.HYPNOSIS, durationTicks, 0, false, false, true);
            target.addEffect(instance, player);
            HypnoData.setMaster(target, player.getUUID());
            last = target;

            level.playSound(null, target.getX(), target.getEyeY(), target.getZ(), ModSounds.SUCCESS.get(), target.getSoundSource(), 1.0F, 1.0F);
            spawnBeam(level, beamStart, target.getEyePosition());
            level.sendParticles(ModParticles.HYPNO_RING.get(), target.getX(), target.getEyeY(), target.getZ(), 6, 0.25, 0.25, 0.25, 0.0);
        }
        Component name = targets.size() == 1 ? last.getDisplayName() : Component.literal(String.valueOf(targets.size()));
        player.displayClientMessage(Component.translatable("message.hypnoeye.hypnotized", name), true);
    }

    private static void spawnBeam(ServerLevel level, Vec3 from, Vec3 to) {
        Vec3 delta = to.subtract(from);
        double len = delta.length();
        int steps = (int) Math.min(24, Math.max(2, len * 2.0));
        for (int i = 1; i < steps; i++) {
            Vec3 p = from.add(delta.scale(i / (double) steps));
            level.sendParticles(ModParticles.HYPNO_RING.get(), p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    /** Ray trace along the view direction (blocked by opaque blocks), optionally plus a cone of extra targets. */
    private static List<LivingEntity> findTargets(ServerPlayer player, ServerLevel level) {
        double range = HypnoConfig.RANGE.get();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);

        double maxDist = range;
        BlockHitResult wall = level.clip(new ClipContext(eye, eye.add(look.scale(range)), ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, player));
        if (wall.getType() != HitResult.Type.MISS) {
            maxDist = wall.getLocation().distanceTo(eye);
        }
        Vec3 end = eye.add(look.scale(maxDist));
        AABB box = player.getBoundingBox().expandTowards(look.scale(maxDist)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, box, e -> canTarget(player, e) && e.isPickable(), maxDist * maxDist);

        Set<LivingEntity> result = new LinkedHashSet<>();
        if (hit != null && hit.getEntity() instanceof LivingEntity living) {
            result.add(living);
        }

        if (HypnoConfig.MULTI_TARGET.get()) {
            double cos = Math.cos(Math.toRadians(HypnoConfig.CONE_ANGLE.get()));
            AABB area = new AABB(eye, eye).inflate(range);
            List<LivingEntity> candidates = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class, area, e -> canTarget(player, e)));
            candidates.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));
            int max = HypnoConfig.MAX_TARGETS.get();
            for (LivingEntity candidate : candidates) {
                if (result.size() >= max) {
                    break;
                }
                Vec3 toTarget = candidate.getBoundingBox().getCenter().subtract(eye);
                double dist = toTarget.length();
                if (dist > range || dist < 1.0E-4) {
                    continue;
                }
                if (toTarget.scale(1.0 / dist).dot(look) < cos) {
                    continue;
                }
                BlockHitResult los = level.clip(new ClipContext(eye, candidate.getBoundingBox().getCenter(), ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, player));
                if (los.getType() != HitResult.Type.MISS) {
                    continue;
                }
                result.add(candidate);
            }
        }
        return new ArrayList<>(result);
    }

    /** Category switches, type allow/block lists and sanity checks. */
    public static boolean canTarget(Player caster, Entity entity) {
        if (!(entity instanceof LivingEntity living) || entity == caster || !living.isAlive() || entity.isSpectator() || entity instanceof ArmorStand) {
            return false;
        }
        if (entity instanceof Player) {
            if (!HypnoConfig.AFFECT_PLAYERS.get()) {
                return false;
            }
        } else if (entity instanceof NeutralMob) {
            if (!HypnoConfig.AFFECT_NEUTRAL.get()) {
                return false;
            }
        } else if (entity instanceof Enemy) {
            if (!HypnoConfig.AFFECT_HOSTILE.get()) {
                return false;
            }
        } else if (!HypnoConfig.AFFECT_PASSIVE.get()) {
            return false;
        }
        String key = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
        List<? extends String> allowed = HypnoConfig.ALLOWED_ENTITIES.get();
        if (!allowed.isEmpty() && !allowed.contains(key)) {
            return false;
        }
        return !HypnoConfig.BLOCKED_ENTITIES.get().contains(key);
    }

    private HypnosisLogic() {}
}
