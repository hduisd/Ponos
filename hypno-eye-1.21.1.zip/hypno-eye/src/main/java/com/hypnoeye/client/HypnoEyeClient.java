package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

/** Client-only entry point: gives the mod an in-game config screen (Mods -> Hypno Eye -> Config). */
@Mod(value = HypnoEye.MODID, dist = Dist.CLIENT)
public class HypnoEyeClient {
    public HypnoEyeClient(ModContainer container) {
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }
}
