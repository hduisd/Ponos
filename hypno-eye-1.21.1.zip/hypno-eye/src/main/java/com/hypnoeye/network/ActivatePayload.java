package com.hypnoeye.network;

import com.hypnoeye.HypnoEye;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: "I pressed the key". Carries no data: the server uses the player's own look direction. */
public record ActivatePayload() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ActivatePayload> TYPE = new CustomPacketPayload.Type<>(HypnoEye.id("activate"));
    public static final StreamCodec<ByteBuf, ActivatePayload> CODEC = StreamCodec.unit(new ActivatePayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
