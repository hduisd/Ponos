package com.hypnoeye.server;

import java.util.UUID;

import com.hypnoeye.HypnoConfig;
import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModEffects;
import com.hypnoeye.registry.ModSounds;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;

@EventBusSubscriber(modid = HypnoEye.MODID)
public final class HypnoEvents {

    /** Subjugation mode: a hypnotized mob can never pick its hypnotist as a target. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity mob = event.getEntity();
        LivingEntity newTarget = event.getNewAboutToBeSetTarget();
        if (newTarget == null || mob.level().isClientSide()) {
            return;
        }
        if (HypnoConfig.MODE.get() != HypnoConfig.Mode.SUBJUGATION || !mob.hasEffect(ModEffects.HYPNOSIS)) {
            return;
        }
        UUID master = HypnoData.getMaster(mob);
        if (master != null && master.equals(newTarget.getUUID())) {
            event.setNewAboutToBeSetTarget(null);
        }
    }

    @SubscribeEvent
    public static void onExpired(MobEffectEvent.Expired event) {
        MobEffectInstance instance = event.getEffectInstance();
        if (instance != null && instance.getEffect().value() == ModEffects.HYPNOSIS.get()) {
            finish(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onRemoved(MobEffectEvent.Remove event) {
        MobEffectInstance instance = event.getEffectInstance();
        if (instance != null && instance.getEffect().value() == ModEffects.HYPNOSIS.get()) {
            finish(event.getEntity());
        }
    }

    /** Death wipes the effect with the entity; just make sure no stale data stays in persistent NBT. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide()) {
            HypnoData.clear(event.getEntity());
        }
    }

    private static void finish(LivingEntity entity) {
        if (entity.level().isClientSide()) {
            return;
        }
        HypnoData.clear(entity);
        entity.level().playSound(null, entity.getX(), entity.getEyeY(), entity.getZ(), ModSounds.END.get(), entity.getSoundSource(), 1.0F, 1.0F);
    }

    private HypnoEvents() {}
}
