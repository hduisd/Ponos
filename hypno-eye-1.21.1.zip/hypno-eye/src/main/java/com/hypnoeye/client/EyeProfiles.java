package com.hypnoeye.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import net.minecraft.world.entity.EntityType;

/**
 * Registry of the mobs whose eyes can turn hypnotic (stage 1). To support another mob just call
 * {@link #register(EntityType, EyeProfile)} before the renderers are built (e.g. in FMLClientSetupEvent).
 */
public final class EyeProfiles {
    private static final Map<EntityType<?>, EyeProfile> PROFILES = new HashMap<>();

    // 8x8x8 head, eyes on the 5th pixel row (zombie, skeleton, player...). Face (with hat layer) is at z = -4.5.
    private static final EyeProfile HUMANOID = new EyeProfile(0F, 0F, 2.0F, -3.0F, -4.55F, 3.4F, -6.0F, 3.8F);
    // 8x10x8 head with a nose (villagers, illagers).
    private static final EyeProfile VILLAGER = new EyeProfile(0F, 0F, 2.0F, -5.5F, -4.3F, 3.0F, -8.2F, 3.4F);
    private static final EyeProfile CREEPER = new EyeProfile(6F, 0F, 2.0F, -5.0F, -4.3F, 3.0F, -7.0F, 3.4F);
    private static final EyeProfile PIG = new EyeProfile(12F, -6F, 2.6F, -1.0F, -8.3F, 2.6F, 0F, 0F);
    private static final EyeProfile COW = new EyeProfile(4F, -8F, 2.8F, -1.0F, -6.3F, 2.6F, 0F, 0F);
    private static final EyeProfile SHEEP = new EyeProfile(6F, -8F, 2.0F, -1.0F, -6.3F, 2.2F, 0F, 0F);

    static {
        register(EntityType.PLAYER, HUMANOID);
        register(EntityType.ZOMBIE, HUMANOID);
        register(EntityType.HUSK, HUMANOID);
        register(EntityType.DROWNED, HUMANOID);
        register(EntityType.SKELETON, HUMANOID);
        register(EntityType.STRAY, HUMANOID);
        register(EntityType.BOGGED, HUMANOID);
        register(EntityType.WITHER_SKELETON, HUMANOID);

        register(EntityType.VILLAGER, VILLAGER);
        register(EntityType.WANDERING_TRADER, VILLAGER);
        register(EntityType.ZOMBIE_VILLAGER, VILLAGER);
        register(EntityType.PILLAGER, VILLAGER);
        register(EntityType.VINDICATOR, VILLAGER);
        register(EntityType.EVOKER, VILLAGER);
        register(EntityType.ILLUSIONER, VILLAGER);

        register(EntityType.CREEPER, CREEPER);
        register(EntityType.PIG, PIG);
        register(EntityType.COW, COW);
        register(EntityType.MOOSHROOM, COW);
        register(EntityType.SHEEP, SHEEP);
    }

    public static void register(EntityType<?> type, EyeProfile profile) {
        PROFILES.put(type, profile);
    }

    public static EyeProfile get(EntityType<?> type) {
        return PROFILES.get(type);
    }

    public static Set<EntityType<?>> types() {
        return PROFILES.keySet();
    }

    private EyeProfiles() {}
}
