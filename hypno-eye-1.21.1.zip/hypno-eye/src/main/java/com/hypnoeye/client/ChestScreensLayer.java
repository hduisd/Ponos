package com.hypnoeye.client;

import java.util.Set;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws the Screens Vest: six big 3D olives (without pits) floating around the head, each held on an olive branch with leaves.
 * The hole of each olive shows the hypno spiral: dim at rest, glowing and spinning while the wearer channels the Hypno Eye.
 * Geometry is in model pixels (1/16 block), Y points down, the back of the body is +Z.
 */
public class ChestScreensLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    /** Entity types with a humanoid body this layer is attached to (the player is added separately). */
    public static final Set<EntityType<?>> WEARERS = Set.of(
            EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.SKELETON,
            EntityType.STRAY, EntityType.BOGGED, EntityType.WITHER_SKELETON);

    private static final ResourceLocation OLIVE = HypnoEye.id("textures/entity/olive_skin.png");
    /** Same pixel animation as the Hypno Eye lens on the head (12 frames: expanding gold rings + jittering white zigzag), just round. */
    private static final ResourceLocation LENS = HypnoEye.id("textures/entity/hypno_lens_round.png");
    private static final int LENS_FRAMES = 12;

    private static final ResourceLocation LEAF = HypnoEye.id("textures/entity/olive_leaf.png");
    private static final int LEAVES = 7;   // leaves per branch (the last one is the tip leaf)
    private static final int LAT = 12;
    private static final int LON = 16;
    private static final float HOLE = 0.5F;         // hole radius as a fraction of the olive radius
    
    // x, y, z, radius R, roll(deg), phase  - six big pitted olives floating around the head (the hole faces forward), each held by an olive branch
    private static final float[][] OLIVES = {
            {11.0F, -11.0F, 7.0F, 5.8F, -14.0F, 0.0F},
            {21.0F, -3.0F, 7.5F, 6.6F, 12.0F, 1.3F},
            {16.0F, 7.5F, 6.0F, 5.2F, -16.0F, 2.1F},
            {-11.0F, -11.0F, 7.0F, 5.6F, 16.0F, 3.0F},
            {-21.0F, -4.0F, 7.5F, 6.4F, -10.0F, 4.2F},
            {-16.0F, 7.0F, 6.0F, 5.0F, 18.0F, 5.1F}
    };

    public ChestScreensLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    /** Placement of one olive: roll (about Z), then pitch (about X), then yaw (about Y) around its own centre, then moved to the centre. Model pixels. */
    private record Place(float cr, float sr, float cp, float sp, float cy, float sy, float x, float y, float z) { }

    /** Local olive point -> model-space point (roll, pitch, yaw about the olive's centre). */
    private static float[] xf(Place pl, float x, float y, float z) {
        float x1 = x * pl.cr - y * pl.sr;
        float y1 = x * pl.sr + y * pl.cr;
        float y2 = y1 * pl.cp - z * pl.sp;
        float z2 = y1 * pl.sp + z * pl.cp;
        return new float[] {x1 * pl.cy + z2 * pl.sy, y2, -x1 * pl.sy + z2 * pl.cy};
    }

    private static void vert(VertexConsumer vc, PoseStack.Pose pose, Place pl, float x, float y, float z,
                             float nx, float ny, float nz, float u, float v, float br, int light) {
        float[] p = xf(pl, x, y, z);
        float[] n = xf(pl, nx, ny, nz);
        vc.addVertex(pose, (p[0] + pl.x) / 16.0F, (p[1] + pl.y) / 16.0F, (p[2] + pl.z) / 16.0F)
                .setColor(br, br, br, 1.0F)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, n[0], n[1], n[2]);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || entity.isBaby() || !entity.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.HYPNO_SCREENS.get())) {
            return;
        }
        float open = ClientAnimState.channelOpen(entity, partialTick); // the wearer's Hypno Eye channel drives the holes
        float bright = 0.22F + 0.78F * open;
        PoseStack.Pose pose = poseStack.last();

        Place[] places = new Place[OLIVES.length];
        for (int i = 0; i < OLIVES.length; i++) {
            float[] o = OLIVES[i];
            float bob = Mth.sin(ageInTicks * 0.05F + o[5]) * 1.0F;
            float roll = (o[4] + Mth.sin(ageInTicks * 0.035F + o[5]) * 3.0F) * Mth.DEG_TO_RAD;
            // every olive aims its hole where the wearer is looking (head yaw / pitch), with a tiny idle wobble
            float yaw = netHeadYaw * Mth.DEG_TO_RAD + Mth.sin(ageInTicks * 0.03F + o[5]) * 0.03F;
            float pitch = headPitch * Mth.DEG_TO_RAD + Mth.sin(ageInTicks * 0.04F + o[5] * 1.7F) * 0.03F;
            places[i] = new Place(Mth.cos(roll), Mth.sin(roll), Mth.cos(pitch), Mth.sin(pitch), Mth.cos(yaw), Mth.sin(yaw), o[0], o[1] + bob, o[2]);
        }

        // Pass 1: the olive bodies (lit, textured) and the dark inner walls of the holes.
        // Each pass asks for its own buffer; requesting another one closes the previous, so never interleave them.
        VertexConsumer body = buffer.getBuffer(RenderType.entityCutoutNoCull(OLIVE));
        for (int i = 0; i < OLIVES.length; i++) {
            // a real olive shape: long axis along Z (hole at the front tip, cross at the back tip), round in cross-section
            float r = OLIVES[i][3] * 0.85F;
            float ry = OLIVES[i][3] * 0.8F;
            float rz = OLIVES[i][3] * 1.2F;
            float th0 = (float) Math.asin(HOLE);
            for (int a = 0; a < LAT; a++) {
                float t0 = th0 + (Mth.PI - th0) * a / LAT;
                float t1 = th0 + (Mth.PI - th0) * (a + 1) / LAT;
                for (int b = 0; b < LON; b++) {
                    float f0 = Mth.TWO_PI * b / LON;
                    float f1 = Mth.TWO_PI * (b + 1) / LON;
                    float[][] ts = {{t0, f0}, {t0, f1}, {t1, f1}, {t1, f0}};
                    for (float[] tf : ts) {
                        float st = Mth.sin(tf[0]);
                        float x = r * st * Mth.cos(tf[1]);
                        float y = ry * st * Mth.sin(tf[1]);
                        float z = -rz * Mth.cos(tf[0]);
                        float nx = x / (r * r);
                        float ny = y / (ry * ry);
                        float nz = z / (rz * rz);
                        float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz);
                        float u = (tf[1] == f0 ? (float) b : (float) b + 1) / LON;
                        float v = (tf[0] == t0 ? (float) a : (float) a + 1) / LAT;
                        vert(body, pose, places[i], x, y, z, nx / nl, ny / nl, nz / nl, u, v, 1.0F, packedLight);
                    }
                }
            }
            // inner wall of the hole: a short dark tube going back from the rim
            float zr = -rz * Mth.cos(th0);
            float zEnd = zr + OLIVES[i][3] * 0.7F;
            for (int b = 0; b < LON; b++) {
                float f0 = Mth.TWO_PI * b / LON;
                float f1 = Mth.TWO_PI * (b + 1) / LON;
                float[] fs = {f0, f1, f1, f0};
                float[] zs = {zr, zr, zEnd, zEnd};
                for (int k = 0; k < 4; k++) {
                    float cx = Mth.cos(fs[k]);
                    float sy = Mth.sin(fs[k]);
                    vert(body, pose, places[i], r * HOLE * cx, ry * HOLE * sy, zs[k], -cx, -sy, 0.0F,
                            k == 0 || k == 3 ? 0.1F : 0.4F, k < 2 ? 0.2F : 0.8F, 0.42F, packedLight);
                }
            }

            // The little cross on the back pole, like on pitless olives from a jar: two thin dark slits that follow the surface.
            for (int arm = 0; arm < 2; arm++) {
                int segs = 6;
                float half = r * 0.5F;
                float wid = r * 0.075F;
                for (int sg = 0; sg < segs; sg++) {
                    float p0 = -half + 2.0F * half * sg / segs;
                    float p1 = -half + 2.0F * half * (sg + 1) / segs;
                    float[][] pts = {{p0, -wid}, {p1, -wid}, {p1, wid}, {p0, wid}};
                    for (float[] q : pts) {
                        float x = arm == 0 ? q[0] : q[1];
                        float y = (arm == 0 ? q[1] : q[0]) * (ry / r);
                        float k2 = 1.0F - (x * x) / (r * r) - (y * y) / (ry * ry);
                        float z = rz * Mth.sqrt(Math.max(k2, 0.05F)) + 0.07F;
                        float nx = x / (r * r);
                        float ny = y / (ry * ry);
                        float nz = z / (rz * rz);
                        float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz);
                        vert(body, pose, places[i], x, y, z, nx / nl, ny / nl, nz / nl, 0.5F, 0.5F, 0.28F, packedLight);
                    }
                }
            }
        }

        // Pass 2: the very same lens animation as on the head, deep inside every hole (one frame per 3 ticks, like the eye).
        int frame = open > 0.02F ? ((int) (ageInTicks / 3.0F)) % LENS_FRAMES : 0;
        VertexConsumer disc = buffer.getBuffer(RenderType.entityTranslucentEmissive(LENS));
        for (int i = 0; i < OLIVES.length; i++) {
            quad(disc, pose, places[i], OLIVES[i], 1.0F, 0.0F, frame / (float) LENS_FRAMES, 1.0F / LENS_FRAMES, bright);
        }

        // Branches: curve from the back to the rear of each olive; stem as thin lines, leaves as textured quads.
        float[][][] curves = new float[OLIVES.length][][];
        for (int i = 0; i < OLIVES.length; i++) {
            float[] o = OLIVES[i];
            float side = Math.signum(o[0]);
            Place pl = places[i];
            float[] start = {side * 2.0F, 2.0F, 2.6F};
            float[] tail = xf(pl, 0.0F, 0.0F, o[3] * 1.1F);   // the back tip of the olive, wherever it points now
            float[] end = {pl.x + tail[0], pl.y + tail[1], pl.z + tail[2]};
            float[] ctrl = {(start[0] + end[0]) * 0.5F + side * 2.0F, (start[1] + end[1]) * 0.5F + 4.5F, (start[2] + end[2]) * 0.5F + 1.5F};
            curves[i] = new float[][] {start, ctrl, end};
        }

        // Pass 3: leaves (alternating pairs along the branch, a bit of sway).
        VertexConsumer leaves = buffer.getBuffer(RenderType.entityCutoutNoCull(LEAF));
        for (int i = 0; i < OLIVES.length; i++) {
            float[][] c = curves[i];
            for (int k = 0; k <= LEAVES; k++) {
                float t = k == LEAVES ? 1.0F : 0.2F + 0.72F * k / LEAVES;
                float[] p0 = bez(c, t);
                float[] pa = bez(c, Math.max(0.0F, t - 0.03F));
                float[] pb = bez(c, Math.min(1.0F, t + 0.03F));
                float tx = pb[0] - pa[0];
                float ty = pb[1] - pa[1];
                float tl = Mth.sqrt(tx * tx + ty * ty);
                if (tl < 1.0E-4F) {
                    continue;
                }
                tx /= tl;
                ty /= tl;
                float sgn = (k % 2 == 0) ? 1.0F : -1.0F;
                float ang = k == LEAVES ? 0.0F : (0.62F + 0.08F * Mth.sin(ageInTicks * 0.06F + k + OLIVES[i][5])) * sgn;
                float dx = tx * Mth.cos(ang) + ty * Mth.sin(ang);   // rotate the stem direction by ang (in the XY plane)
                float dy = -tx * Mth.sin(ang) + ty * Mth.cos(ang);
                float len = (5.0F + 2.0F * t) * (k == LEAVES ? 1.15F : 1.0F);
                float hw = len * 0.16F;
                float wx = -dy * hw;
                float wy = dx * hw;
                float tipx = p0[0] + dx * len;
                float tipy = p0[1] + dy * len;
                float z = p0[2] + (k % 2 == 0 ? 0.0F : 0.15F);
                float br = k % 3 == 0 ? 1.0F : 0.88F;
                leaf(leaves, pose, p0[0] - wx * 0.25F, p0[1] - wy * 0.25F, z, 0.0F, 1.0F, br, packedLight);
                leaf(leaves, pose, p0[0] + wx * 0.25F, p0[1] + wy * 0.25F, z, 1.0F, 1.0F, br, packedLight);
                leaf(leaves, pose, tipx + wx, tipy + wy, z, 1.0F, 0.0F, br, packedLight);
                leaf(leaves, pose, tipx - wx, tipy - wy, z, 0.0F, 0.0F, br, packedLight);
            }
        }

        // Pass 4: the thin grey-brown stems.
        VertexConsumer stems = buffer.getBuffer(RenderType.lines());
        for (int i = 0; i < OLIVES.length; i++) {
            float[] prev = curves[i][0];
            for (int k = 1; k <= 10; k++) {
                float[] cur = bez(curves[i], k / 10.0F);
                float dx = cur[0] - prev[0];
                float dy = cur[1] - prev[1];
                float dz = cur[2] - prev[2];
                float l = Mth.sqrt(dx * dx + dy * dy + dz * dz);
                if (l > 1.0E-4F) {
                    stems.addVertex(pose, prev[0] / 16.0F, prev[1] / 16.0F, prev[2] / 16.0F).setColor(132, 122, 98, 255).setNormal(pose, dx / l, dy / l, dz / l);
                    stems.addVertex(pose, cur[0] / 16.0F, cur[1] / 16.0F, cur[2] / 16.0F).setColor(132, 122, 98, 255).setNormal(pose, dx / l, dy / l, dz / l);
                }
                prev = cur;
            }
        }
    }

    private static float[] bez(float[][] c, float t) {
        float u = 1.0F - t;
        return new float[] {
                u * u * c[0][0] + 2.0F * u * t * c[1][0] + t * t * c[2][0],
                u * u * c[0][1] + 2.0F * u * t * c[1][1] + t * t * c[2][1],
                u * u * c[0][2] + 2.0F * u * t * c[1][2] + t * t * c[2][2]};
    }

    private static void leaf(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v, float br, int light) {
        vc.addVertex(pose, x / 16.0F, y / 16.0F, z / 16.0F)
                .setColor(br, br, br, 1.0F)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, 0.0F, 0.0F, -1.0F);
    }

    /** A flat quad sitting at the bottom of the hole, facing forward. {@code scale} is relative to the hole radius. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, Place pl, float[] o, float scale, float spin,
                             float u0, float uw, float br) {
        float r = o[3] * 0.85F * HOLE * 1.02F * scale;
        float ry = o[3] * 0.8F * HOLE * 1.02F * scale;
        float zq = -o[3] * 1.2F * Mth.cos((float) Math.asin(HOLE)) + o[3] * 0.7F - 0.05F;
        float c = Mth.cos(spin);
        float s = Mth.sin(spin);
        float[][] corners = {{-1, -1}, {-1, 1}, {1, 1}, {1, -1}};
        for (float[] k : corners) {
            float x = k[0] * r;
            float y = k[1] * ry;
            vert(vc, pose, pl, x * c - y * s, x * s + y * c, zq, 0.0F, 0.0F, -1.0F,
                    u0 + (k[0] < 0 ? 0.0F : uw), k[1] < 0 ? 0.0F : 1.0F, br, LightTexture.FULL_BRIGHT);
        }
    }
}
