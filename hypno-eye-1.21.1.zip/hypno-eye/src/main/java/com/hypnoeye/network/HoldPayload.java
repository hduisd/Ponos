package com.hypnoeye.network;

import com.hypnoeye.HypnoEye;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: the activation key is held (true, repeated as a heartbeat) or released (false). */
public record HoldPayload(boolean held) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<HoldPayload> TYPE = new CustomPacketPayload.Type<>(HypnoEye.id("hold"));
    public static final StreamCodec<ByteBuf, HoldPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, HoldPayload::held,
            HoldPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
