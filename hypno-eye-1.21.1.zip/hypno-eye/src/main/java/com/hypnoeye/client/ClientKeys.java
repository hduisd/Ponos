package com.hypnoeye.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;

public final class ClientKeys {
    /** Appears in Options -> Controls -> Key Binds -> "Hypno Eye" and can be rebound there. */
    public static final KeyMapping ACTIVATE = new KeyMapping(
            "key.hypnoeye.activate", InputConstants.Type.KEYSYM, InputConstants.KEY_H, "key.categories.hypnoeye");

    private ClientKeys() {}
}
