package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.network.ActivatePayload;
import com.hypnoeye.registry.ModItems;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = HypnoEye.MODID, value = Dist.CLIENT)
public final class ClientGameEvents {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            ClientAnimState.clearAll();
            return;
        }
        while (ClientKeys.ACTIVATE.consumeClick()) {
            ItemStack head = mc.player.getItemBySlot(EquipmentSlot.HEAD);
            if (!head.is(ModItems.HYPNO_EYE.get()) || mc.player.isSpectator()) {
                continue;
            }
            if (mc.player.getCooldowns().isOnCooldown(head.getItem())) {
                mc.player.displayClientMessage(Component.translatable("message.hypnoeye.cooldown"), true);
                continue;
            }
            // the client only asks; the server checks everything again
            PacketDistributor.sendToServer(new ActivatePayload());
        }
        if (mc.level.getGameTime() % 100L == 0L) {
            ClientAnimState.cleanup(mc.level);
        }
    }

    private ClientGameEvents() {}
}
