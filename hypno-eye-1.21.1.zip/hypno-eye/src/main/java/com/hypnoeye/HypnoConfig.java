package com.hypnoeye;

import java.util.List;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.common.ModConfigSpec;

/** All settings of the mod (file: config/hypnoeye-common.toml, also editable from Mods -> Hypno Eye -> Config). */
public final class HypnoConfig {
    public enum Mode {
        /** Mode A: only the eyes of the target change. Behaviour is untouched. */
        VISUAL,
        /** Mode B: eyes change AND the target will not attack the caster (and may follow him). */
        SUBJUGATION
    }

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.IntValue DURATION_SECONDS = B
            .comment("How long the hypnosis lasts, in seconds. Re-applying never stacks, it only resets to this value.")
            .defineInRange("durationSeconds", 150, 1, 36000);
    public static final ModConfigSpec.DoubleValue RANGE = B
            .comment("Maximum distance of the ability in blocks.")
            .defineInRange("range", 12.0, 1.0, 64.0);
    public static final ModConfigSpec.DoubleValue COOLDOWN_SECONDS = B
            .comment("Cooldown of the ability in seconds (a miss only costs 1 second).")
            .defineInRange("cooldownSeconds", 7.0, 0.0, 3600.0);

    public static final ModConfigSpec.BooleanValue AFFECT_PLAYERS = B
            .comment("Can players be hypnotized?")
            .define("affectPlayers", true);
    public static final ModConfigSpec.BooleanValue AFFECT_HOSTILE = B
            .comment("Can hostile mobs (zombie, skeleton, creeper...) be hypnotized?")
            .define("affectHostileMobs", true);
    public static final ModConfigSpec.BooleanValue AFFECT_NEUTRAL = B
            .comment("Can neutral mobs (wolf, enderman, bee, iron golem...) be hypnotized?")
            .define("affectNeutralMobs", true);
    public static final ModConfigSpec.BooleanValue AFFECT_PASSIVE = B
            .comment("Can passive creatures (pig, cow, villager...) be hypnotized?")
            .define("affectPassiveMobs", true);

    public static final ModConfigSpec.EnumValue<Mode> MODE = B
            .comment("VISUAL = only the eyes change (mode A). SUBJUGATION = eyes change, the mob does not attack the caster and follows him (mode B).")
            .defineEnum("mode", Mode.VISUAL);

    public static final ModConfigSpec.BooleanValue MULTI_TARGET = B
            .comment("Hypnotize every creature inside a small cone in front of the player, not only the one you look at.")
            .define("multiTarget", false);
    public static final ModConfigSpec.DoubleValue CONE_ANGLE = B
            .comment("Half-angle of the cone (degrees) used when multiTarget is on.")
            .defineInRange("coneAngleDegrees", 20.0, 1.0, 90.0);
    public static final ModConfigSpec.IntValue MAX_TARGETS = B
            .comment("Maximum number of creatures hypnotized at once when multiTarget is on.")
            .defineInRange("maxTargets", 5, 1, 32);

    public static final ModConfigSpec.ConfigValue<List<? extends String>> ALLOWED_ENTITIES = B
            .comment("If not empty, ONLY these entity types can be hypnotized, e.g. [\"minecraft:zombie\", \"minecraft:pig\"]. Empty = all.")
            .defineListAllowEmpty("allowedEntities", List.of(), () -> "minecraft:zombie", HypnoConfig::validId);
    public static final ModConfigSpec.ConfigValue<List<? extends String>> BLOCKED_ENTITIES = B
            .comment("Entity types that can never be hypnotized.")
            .defineListAllowEmpty("blockedEntities", List.of("minecraft:ender_dragon", "minecraft:wither"), () -> "minecraft:wither", HypnoConfig::validId);

    public static final ModConfigSpec.BooleanValue SUBJ_FOLLOW = B
            .comment("SUBJUGATION mode: the hypnotized mob walks after the caster.")
            .define("subjugationFollow", true);
    public static final ModConfigSpec.DoubleValue SUBJ_FOLLOW_DISTANCE = B
            .comment("SUBJUGATION mode: the mob starts following when farther than this many blocks.")
            .defineInRange("subjugationFollowDistance", 4.0, 1.0, 32.0);
    public static final ModConfigSpec.DoubleValue SUBJ_FOLLOW_SPEED = B
            .comment("SUBJUGATION mode: walking speed multiplier while following.")
            .defineInRange("subjugationFollowSpeed", 1.1, 0.1, 3.0);

    public static final ModConfigSpec SPEC = B.build();

    private static boolean validId(Object o) {
        return o instanceof String s && ResourceLocation.tryParse(s) != null;
    }

    private HypnoConfig() {}
}
