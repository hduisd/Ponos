package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModEffects;
import com.hypnoeye.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * One extra render layer, added to the renderers of the supported mobs and of the player. It draws:
 *  1) hypnotic eyes (rotating spiral iris + flickering zigzag pupil) on every entity that has the Hypnosis effect;
 *  2) the Hypno Eye lens on the LEFT eye of every entity wearing the item (appears, spins and glows only during activation).
 * The state is read from synced game data (effect / equipment), so all players see the same thing.
 * Cost: a handful of textured quads per hypnotized/equipped entity - no FPS impact.
 */
public class HypnoEyesLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation SPIRAL = HypnoEye.id("textures/entity/hypno_spiral.png");
    private static final ResourceLocation PUPIL = HypnoEye.id("textures/entity/hypno_pupil.png");
    /** Pixel-art lens animation (worn eye): 12 frames of 16x16 in one strip - expanding black rings + jittering white zigzag. */
    private static final ResourceLocation LENS = HypnoEye.id("textures/entity/hypno_lens.png");
    private static final int LENS_FRAMES = 12;

    public HypnoEyesLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || entity.isBaby()) {
            return;
        }
        EyeProfile profile = EyeProfiles.get(entity.getType());
        if (profile == null) {
            return;
        }
        MobEffectInstance hypno = entity.getEffect(ModEffects.HYPNOSIS);
        if (hypno == null) {
            ClientAnimState.forget(entity.getId());
            return;
        }

        poseStack.pushPose();
        // move into the head's coordinate system (follows head rotation, sneaking, etc.)
        if (this.getParentModel() instanceof HeadedModel headed) {
            headed.getHead().translateAndRotate(poseStack);
        } else {
            poseStack.translate(0.0F, profile.pivotY() / 16.0F, profile.pivotZ() / 16.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(netHeadYaw));
            poseStack.mulPose(Axis.XP.rotationDegrees(headPitch));
        }

        float t = ageInTicks;
        if (hypno != null) {
            float alpha = ClientAnimState.hypnoAlpha(entity, hypno, partialTick);
            if (alpha > 0.01F) {
                float pulse = 1.0F + 0.10F * Mth.sin(t * 0.25F);
                int frame = ((int) (t / 6.0F)) & 3; // flickering zigzag pupil, ~3 fps (slowed down)
                for (int side = -1; side <= 1; side += 2) {
                    drawEye(poseStack, buffer, side * profile.eyeX(), profile.eyeY(), profile.faceZ(),
                            profile.eyeSize() * 0.5F * pulse, 1.0F, side * t * 4.0F, alpha, alpha, frame);
                }
            }
        }
        poseStack.popPose();
    }

    /** Spiral iris (rotated) + pupil frame (not rotated), both squashed vertically by {@code lid}. Units: model pixels. */
    private static void drawEye(PoseStack ps, MultiBufferSource buffer, float cx, float cy, float z, float half, float lid,
                                float angleDeg, float irisAlpha, float pupilAlpha, int pupilFrame) {
        PoseStack.Pose pose = ps.last();
        float rad = angleDeg * Mth.DEG_TO_RAD;
        float c = Mth.cos(rad);
        float s = Mth.sin(rad);

        VertexConsumer iris = buffer.getBuffer(RenderType.entityTranslucentEmissive(SPIRAL));
        // corners of the square rotated by the angle, then squashed vertically (eyelid)
        float[] xs = {-half, -half, half, half};
        float[] ys = {-half, half, half, -half};
        float[] us = {0.0F, 0.0F, 1.0F, 1.0F};
        float[] vs = {0.0F, 1.0F, 1.0F, 0.0F};
        for (int i = 0; i < 4; i++) {
            float rx = xs[i] * c - ys[i] * s;
            float ry = (xs[i] * s + ys[i] * c) * lid;
            vertex(iris, pose, cx + rx, cy + ry, z, us[i], vs[i], irisAlpha);
        }

        if (pupilAlpha > 0.01F) {
            VertexConsumer pupil = buffer.getBuffer(RenderType.entityTranslucentEmissive(PUPIL));
            float u0 = pupilFrame * 0.25F;
            float u1 = u0 + 0.25F;
            float h = half * 0.92F;
            float hh = h * lid;
            float zp = z - 0.03F;
            vertex(pupil, pose, cx - h, cy - hh, zp, u0, 0.0F, pupilAlpha);
            vertex(pupil, pose, cx - h, cy + hh, zp, u0, 1.0F, pupilAlpha);
            vertex(pupil, pose, cx + h, cy + hh, zp, u1, 1.0F, pupilAlpha);
            vertex(pupil, pose, cx + h, cy - hh, zp, u1, 0.0F, pupilAlpha);
        }
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v, float alpha) {
        vc.addVertex(pose, x / 16.0F, y / 16.0F, z / 16.0F)
                .setColor(1.0F, 1.0F, 1.0F, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0F, 0.0F, -1.0F);
    }
}
