package com.hypnoeye.server;

import java.util.UUID;

import com.hypnoeye.HypnoConfig;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;

/**
 * The hypnosis state itself. Using a MobEffect gives us, for free: synchronisation to every tracking client,
 * saving in the world, expiry, cleanup on death and "no stacking" (re-applying just resets the timer).
 */
public class HypnosisEffect extends MobEffect {
    public HypnosisEffect() {
        super(MobEffectCategory.NEUTRAL, 0xE0006A);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return duration % 10 == 0;
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.level().isClientSide() || !(entity.level() instanceof ServerLevel level)) {
            return true;
        }
        if (HypnoConfig.MODE.get() != HypnoConfig.Mode.SUBJUGATION || !(entity instanceof Mob mob)) {
            return true;
        }
        UUID masterId = HypnoData.getMaster(mob);
        if (masterId == null) {
            return true;
        }
        Player master = level.getPlayerByUUID(masterId);
        if (master == null || !master.isAlive()) {
            return true;
        }
        // never keep the caster as a target
        if (mob.getTarget() == master) {
            mob.setTarget(null);
        }
        if (master.equals(mob.getLastHurtByMob())) {
            mob.setLastHurtByMob(null);
        }
        if (mob instanceof NeutralMob neutral && masterId.equals(neutral.getPersistentAngerTarget())) {
            neutral.stopBeingAngry();
        }
        // follow the caster (only when the mob is idle, so the normal AI is not fought against)
        if (HypnoConfig.SUBJ_FOLLOW.get() && mob instanceof PathfinderMob && mob.getTarget() == null) {
            double dist = HypnoConfig.SUBJ_FOLLOW_DISTANCE.get();
            if (mob.distanceToSqr(master) > dist * dist && mob.level() == master.level()) {
                mob.getNavigation().moveTo(master, HypnoConfig.SUBJ_FOLLOW_SPEED.get());
            }
        }
        return true;
    }
}
