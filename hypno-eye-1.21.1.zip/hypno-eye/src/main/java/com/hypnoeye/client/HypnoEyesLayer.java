package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModEffects;
import com.hypnoeye.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * One extra render layer, added to the renderers of the supported mobs and of the player. It draws:
 *  1) hypnotic eyes (rotating spiral iris + flickering zigzag pupil) on every entity that has the Hypnosis effect;
 *  2) the Hypno Eye lens on the LEFT eye of every entity wearing the item (appears, spins and glows only during activation).
 * The state is read from synced game data (effect / equipment), so all players see the same thing.
 * Cost: a handful of textured quads per hypnotized/equipped entity - no FPS impact.
 */
public class HypnoEyesLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation SPIRAL = HypnoEye.id("textures/entity/hypno_spiral.png");
    private static final ResourceLocation PUPIL = HypnoEye.id("textures/entity/hypno_pupil.png");

    public HypnoEyesLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || entity.isBaby()) {
            return;
        }
        EyeProfile profile = EyeProfiles.get(entity.getType());
        if (profile == null) {
            return;
        }
        MobEffectInstance hypno = entity.getEffect(ModEffects.HYPNOSIS);
        boolean worn = profile.thirdSize() > 0.0F && entity.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.HYPNO_EYE.get());
        if (hypno == null && !worn) {
            ClientAnimState.forget(entity.getId());
            return;
        }

        poseStack.pushPose();
        // move into the head's coordinate system (follows head rotation, sneaking, etc.)
        if (this.getParentModel() instanceof HeadedModel headed) {
            headed.getHead().translateAndRotate(poseStack);
        } else {
            poseStack.translate(0.0F, profile.pivotY() / 16.0F, profile.pivotZ() / 16.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(netHeadYaw));
            poseStack.mulPose(Axis.XP.rotationDegrees(headPitch));
        }

        float t = ageInTicks;
        if (hypno != null) {
            float alpha = ClientAnimState.hypnoAlpha(entity, hypno, partialTick);
            if (alpha > 0.01F) {
                float pulse = 1.0F + 0.10F * Mth.sin(t * 0.45F);
                int frame = ((int) (t / 3.0F)) & 3; // flickering zigzag pupil, ~7 fps
                for (int side = -1; side <= 1; side += 2) {
                    drawEye(poseStack, buffer, side * profile.eyeX(), profile.eyeY(), profile.faceZ(),
                            profile.eyeSize() * 0.5F * pulse, 1.0F, side * t * 12.0F, alpha, alpha, frame);
                }
            }
        }
        if (worn) {
            drawWornEye(poseStack, buffer, entity, profile, t, partialTick);
        }
        poseStack.popPose();
    }

    /** The Hypno Eye is a lens on the wearer's LEFT eye: invisible when idle, shown only while the ability is channeled. */
    private void drawWornEye(PoseStack ps, MultiBufferSource buffer, T entity, EyeProfile profile, float t, float partialTick) {
        float open = ClientAnimState.channelOpen(entity, partialTick);
        if (open < 0.02F) {
            return; // idle: nothing is drawn
        }
        float spin = t * (6.0F + 26.0F * open);
        float half = profile.thirdSize() * 0.5F * (1.0F + 0.12F * Mth.sin(t * 0.9F));
        float cx = profile.eyeX();   // +X in model space is the character's left side
        float cy = profile.eyeY();
        float z = profile.faceZ() - 0.05F;

        // glowing halo, counter-rotating
        drawEye(ps, buffer, cx, cy, z + 0.04F, half * (1.5F + 0.25F * Mth.sin(t * 0.7F)), open, -spin * 0.6F, 0.45F * open, 0.0F, 0);
        drawEye(ps, buffer, cx, cy, z, half, open, spin, open, open, ((int) (t / 3.0F)) & 3);
    }

    /** Spiral iris (rotated) + pupil frame (not rotated), both squashed vertically by {@code lid}. Units: model pixels. */
    private static void drawEye(PoseStack ps, MultiBufferSource buffer, float cx, float cy, float z, float half, float lid,
                                float angleDeg, float irisAlpha, float pupilAlpha, int pupilFrame) {
        PoseStack.Pose pose = ps.last();
        float rad = angleDeg * Mth.DEG_TO_RAD;
        float c = Mth.cos(rad);
        float s = Mth.sin(rad);

        VertexConsumer iris = buffer.getBuffer(RenderType.entityTranslucentEmissive(SPIRAL));
        // corners of the square rotated by the angle, then squashed vertically (eyelid)
        float[] xs = {-half, -half, half, half};
        float[] ys = {-half, half, half, -half};
        float[] us = {0.0F, 0.0F, 1.0F, 1.0F};
        float[] vs = {0.0F, 1.0F, 1.0F, 0.0F};
        for (int i = 0; i < 4; i++) {
            float rx = xs[i] * c - ys[i] * s;
            float ry = (xs[i] * s + ys[i] * c) * lid;
            vertex(iris, pose, cx + rx, cy + ry, z, us[i], vs[i], irisAlpha);
        }

        if (pupilAlpha > 0.01F) {
            VertexConsumer pupil = buffer.getBuffer(RenderType.entityTranslucentEmissive(PUPIL));
            float u0 = pupilFrame * 0.25F;
            float u1 = u0 + 0.25F;
            float h = half * 0.92F;
            float hh = h * lid;
            float zp = z - 0.03F;
            vertex(pupil, pose, cx - h, cy - hh, zp, u0, 0.0F, pupilAlpha);
            vertex(pupil, pose, cx - h, cy + hh, zp, u0, 1.0F, pupilAlpha);
            vertex(pupil, pose, cx + h, cy + hh, zp, u1, 1.0F, pupilAlpha);
            vertex(pupil, pose, cx + h, cy - hh, zp, u1, 0.0F, pupilAlpha);
        }
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v, float alpha) {
        vc.addVertex(pose, x / 16.0F, y / 16.0F, z / 16.0F)
                .setColor(1.0F, 1.0F, 1.0F, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0F, 0.0F, -1.0F);
    }
}
