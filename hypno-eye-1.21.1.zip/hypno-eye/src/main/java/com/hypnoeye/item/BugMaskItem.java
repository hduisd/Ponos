package com.hypnoeye.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** The Bean Beetle Mask: a real helmet. Its extra insect parts are drawn by the client layer BugMaskLayer. */
public class BugMaskItem extends ArmorItem {
    public BugMaskItem(Holder<ArmorMaterial> material, Properties properties) {
        super(material, ArmorItem.Type.HELMET, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.hypnoeye.bug_mask.desc1").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("item.hypnoeye.bug_mask.desc2").withStyle(ChatFormatting.GRAY));
    }
}
