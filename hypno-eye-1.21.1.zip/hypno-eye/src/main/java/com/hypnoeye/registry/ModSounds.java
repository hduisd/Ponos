package com.hypnoeye.registry;

import com.hypnoeye.HypnoEye;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, HypnoEye.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> ACTIVATE = register("hypno_activate");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUCCESS = register("hypno_success");
    public static final DeferredHolder<SoundEvent, SoundEvent> END = register("hypno_end");
    public static final DeferredHolder<SoundEvent, SoundEvent> LOOP = register("hypno_loop");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(HypnoEye.id(name)));
    }

    private ModSounds() {}
}
