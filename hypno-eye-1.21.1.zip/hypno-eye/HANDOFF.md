# Hypno Eye / Око гіпнозу — передача проєкту (HANDOFF)

Мод для NeoForge 1.21.1 (Java 21). modid `hypnoeye`, пакет `com.hypnoeye`. Збірка тільки через GitHub Actions (локально Maven недоступний, Claude мод НЕ компілював — усе перевірялось лише у вас у грі).

## Як збирати
- Репозиторій з цим проєктом; `.github/workflows/build.yml` робить `./gradlew build` (JDK 21) і викладає jar як artifact.
- Якщо в репозиторії лежить лише zip: workflow розпаковує `hypno-eye-1.21.1.zip`, знаходить папку з build.gradle, збирає (Gradle 8.14.3).
- Версії: NeoForge 21.1.176, NeoGradle userdev 7.0.170, mojmap + parchment 2024.11.17.
- gradle.properties — тільки ASCII/англійською (ISO-8859-1). Українські назви лише в lang json.
- При помилці: киньте лог Actions або `latest.log` з гри.

## Що вміє мод
- **Око гіпнозу** (`hypno_eye`, слот голови): рецепт GAG/AEA/GAG (золотий злиток, аметист, око Ендера). Носиться як лінза на ЛІВОМУ оці, видима лише під час активації (піксельний «екранчик», трохи скошений, виступає за голову, анімація кілець з hypno_lens.png, 12 кадрів).
- **Нагрудник екранів** (`hypno_screens`, слот грудей): рецепт GIG/IRI/III (скляна панель, залізо, редстоун). 6 екранів на дротах за спиною, тьмяні в спокої, світяться й грають анімацію під час каналу ока. Рендер також на гуманоїдних мобах.
- **Активація**: клавіша H (перепризначувана). Утримання = безперервний гіпноз. Клієнт шле HoldPayload(held) при натисканні + heartbeat кожні 5 тік; сервер пульсує кожні 5 тік, таймаут 20 тік, кулдаун при відпусканні (повний, якщо когось влучило; 20 тік, якщо промах).
- Сервер авторитетний: перевіряє предмет, кулдаун, дальність, стіни (рейтрейс 12 блоків, крізь непрозорі блоки не б'є), валідність цілі; опційно конус для мульти-цілі.
- **Гіпноз** = власний MobEffect `hypnosis` (синхронізується, зберігається в NBT). Майстер-UUID у `getPersistentData()` ключ `hypnoeye_master`. Режими: VISUAL (за замовчуванням) і SUBJUGATION (ціль не атакує кастера, може іти за ним). Очищення стану при закінченні/смерті/виході/перезавантаженні.
- Очі загіпнозованих істот змінюються (спіраль + зіниця) для інших гравців; профілі очей по типах сутностей у `EyeProfiles`.
- Ефекти на екрані кастера: дуже легке червоне тонування (0.12) + тонкі дрібні електричні іскри (ActivationOverlay), частинки кілець, зациклений звук `hypno_loop.ogg` (єдиний звук, вирізаний з відео користувача; інших звуків немає).
- Конфіг (ModConfigSpec + екран у грі): durationSeconds 150, range 12, cooldownSeconds 7, affectPlayers/Hostile/Neutral/Passive, mode, multiTarget false, coneAngleDegrees 20, maxTargets 5, allowedEntities [], blockedEntities [ender_dragon, wither], subjugationFollow/Distance/Speed.
- Українська (uk_ua) та англійська локалізація.

## Структура коду (src/main/java/com/hypnoeye)
- `HypnoEye` — головний клас, реєстри, творча вкладка COMBAT; `HypnoConfig`.
- `registry/` ModItems, ModEffects, ModSounds, ModParticles.
- `item/` HypnoEyeItem (HEAD), HypnoScreensItem (CHEST), обидва Equipable.
- `server/` HypnoData, HypnosisEffect, HypnosisLogic (hold/pulse/пошук цілей/кулдаун), HypnoEvents (зміна цілі, expiry, смерть, logout, stop).
- `network/` HoldPayload, AnimPayload(entityId, active), ModNetwork (registrar "1").
- `client/` ClientKeys, ClientGameEvents (hold + heartbeat), ClientAnimState (стан каналу, `channelOpen(entity, partial)`), HypnoLoopSound, ActivationOverlay, HypnoRingParticle, HypnoEyesLayer (лінза + очі мобів), ChestScreensLayer (екрани + дроти), EyeProfile/EyeProfiles, ClientModEvents (реєстрація шарів, ключів, частинок, GUI), HypnoEyeClient (екран конфігу).
- Ресурси: assets/hypnoeye/{lang, models/item, particles, sounds(.json + hypno_loop.ogg), textures/{item,mob_effect,entity,particle}}, data/hypnoeye/recipe/ (однина `recipe`, результат `"result":{"id":...}`).
- `tools/gen_assets.py` (Python + Pillow/numpy) генерує текстури (hypno_lens.png 192x16, спіраль, зіниця, іконки). Звук користувача НЕ генерується.

## Виправлені помилки / уроки (не повторювати)
- `PlayerSkin` імпортувати з `net.minecraft.client.resources.PlayerSkin`.
- Не брати кілька `buffer.getBuffer(...)` одночасно: другий закриває перший («Not building!» → вильот в інвентарі/F5). Малювати по черзі: спочатку один RenderType, потім інший.
- VertexConsumer 1.21: `addVertex(pose,x,y,z).setColor().setUv().setOverlay().setLight().setNormal(pose,...)`.
- Конфіг і properties: без не-ASCII в gradle.properties.

## Відомі відкриті питання
- Позиції/нахили екранів нагрудника підібрані навмання, потребують підгонки за скріншотом (reference: персонаж з ТВ-головою та екранами на проводах).
- Нічого не збиралось Claude-ом локально; після кожної зміни потрібен прогін Actions.

## Промпт для нового акаунту (скопіюйте разом із цим zip)
> Це мій Minecraft-мод Hypno Eye (NeoForge 1.21.1, Java 21), у вкладеному zip. Прочитай HANDOFF.md і продовжуй працювати над ним. Збірки локально нема — я збираю через GitHub Actions і кидаю тобі логи/скріншоти. Не стверджуй, що щось зібрано чи протестовано, якщо це не так. Відповідай українською. Далі хочу: <нове завдання>.
