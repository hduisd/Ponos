package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** While the ability plays, the screen gets a very light red tint with small drifting particles. */
public final class ActivationOverlay {
    private static final ResourceLocation RING = HypnoEye.id("textures/particle/hypno_ring.png");
    private static final int PARTICLES = 36;

    public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }
        float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
        float p = ClientAnimState.activationProgress(mc.player, partial);
        if (p < 0.0F) {
            return;
        }
        float fade = ClientAnimState.smooth(p / 0.25F) * (1.0F - ClientAnimState.smooth((p - 0.6F) / 0.4F));
        int w = g.guiWidth();
        int h = g.guiHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // very light red tint
        int tint = (int) (0.12F * fade * 255.0F);
        g.fill(0, 0, w, h, (tint << 24) | 0xE00020);

        // small particles drifting upwards
        for (int i = 0; i < PARTICLES; i++) {
            float seedA = frac(i * 0.61803F);
            float seedB = frac(i * 0.37F + 0.2F);
            float seedC = frac(i * 0.8191F + 0.5F);
            float life = frac(p * (1.2F + seedC) + seedA);          // 0..1 loop
            float x = seedA * w + Mth.sin((p * 6.0F + i) * 1.7F) * 12.0F;
            float y = h * (1.05F - life * 1.1F) - seedB * 30.0F;
            int size = 5 + (int) (seedB * 9.0F);
            float a = fade * Mth.sin(life * (float) Math.PI) * 0.7F;
            g.setColor(1.0F, 0.15F + 0.3F * seedC, 0.3F, a);
            g.blit(RING, (int) x, (int) y, 0.0F, 0.0F, size, size, size, size);
        }

        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    private static float frac(float v) {
        return v - (float) Math.floor(v);
    }

    private ActivationOverlay() {}
}
