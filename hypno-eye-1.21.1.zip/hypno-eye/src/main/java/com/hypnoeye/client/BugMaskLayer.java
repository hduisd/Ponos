package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * The Bean Beetle Mask: a mechanical insect mask drawn on top of the helmet (which itself is a normal armor piece).
 * Parts (all in head model pixels, Y points down, the face looks towards -Z):
 *  - a faceted compound-eye visor with a wasp-like angry V brow,
 *  - eight glowing spider eyes (2 big, 2 lateral, 2+2 small),
 *  - two segmented antennae that sway,
 *  - beetle mandibles that open wide while the wearer channels the hypnosis,
 *  - gold / green plates, rivets, cheek vents and a spiky crest.
 */
public class BugMaskLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation PARTS = HypnoEye.id("textures/entity/bug_mask_parts.png");
    private static final ResourceLocation EYE = HypnoEye.id("textures/entity/bug_eye.png");

    // swatch indices in the parts atlas (top-left 32x4 strip, 8 swatches of 4x4 px)
    private static final int DG = 0;   // deep green
    private static final int G = 1;    // green
    private static final int LG = 2;   // light green
    private static final int DY = 3;   // dark gold
    private static final int Y = 4;    // gold
    private static final int LY = 5;   // light gold
    private static final int BK = 6;   // near black
    private static final int ST = 7;   // grey-green steel

    // spider eyes: x (mirrored), y, half size, roll in degrees
    private static final float[][] EYES = {
            {1.6F, -3.5F, 1.05F, 8.0F},
            {3.5F, -4.0F, 0.75F, 18.0F},
            {2.2F, -5.2F, 0.50F, 10.0F},
            {4.0F, -5.6F, 0.55F, 25.0F}
    };

    // mandible centre line (local coordinates for the right-hand jaw: inward is -X, down is +Y, forward is -Z)
    private static final float[][] JAW = {
            {0.0F, 0.0F, 0.0F}, {-0.3F, 1.4F, -1.2F}, {-1.0F, 2.8F, -2.4F},
            {-2.0F, 3.8F, -3.4F}, {-3.0F, 4.2F, -4.0F}, {-3.7F, 3.5F, -4.5F}
    };
    private static final float[] JAW_W = {0.95F, 0.85F, 0.70F, 0.55F, 0.38F, 0.08F};

    public BugMaskLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || !entity.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.BUG_MASK.get())) {
            return;
        }
        if (!(this.getParentModel() instanceof HeadedModel headed)) {
            return;
        }
        float open = ClientAnimState.channelOpen(entity, partialTick);

        poseStack.pushPose();
        headed.getHead().translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();

        // pass 1: the metal parts (lit, textured atlas)
        VertexConsumer parts = buffer.getBuffer(RenderType.entityCutoutNoCull(PARTS));
        Pen pen = new Pen(parts, pose, packedLight);
        drawPlates(pen);
        drawCrest(pen);
        drawMandibles(pen, ageInTicks, open);
        drawAntennae(pen, ageInTicks, open);

        // pass 2: the glowing eyes (a second buffer closes the first one, so it goes strictly after)
        VertexConsumer eyes = buffer.getBuffer(RenderType.entityTranslucentEmissive(EYE));
        Pen glow = new Pen(eyes, pose, LightTexture.FULL_BRIGHT);
        drawEyes(glow, ageInTicks, open);

        poseStack.popPose();
    }

    // ------------------------------------------------------------------------------------------ geometry

    private static float panelZ(float ax) {
        return -5.55F + 0.35F * (Math.abs(ax) / 4.6F);   // the visor is slightly bent back towards the temples
    }

    private static float visorTop(float ax) {
        return -5.3F - 1.5F * (Math.abs(ax) / 4.6F);     // angry V: the top edge is lowest in the middle
    }

    private static void drawPlates(Pen p) {
        for (int k = 0; k < 2; k++) {
            float s = k == 0 ? -1.0F : 1.0F;
            // faceted visor: front half + wrap around the temple (hex tile of the atlas)
            float[] c0 = {0.0F, visorTop(0.0F), panelZ(0.0F)};
            float[] c1 = {s * 4.6F, visorTop(4.6F), panelZ(4.6F)};
            float[] c2 = {s * 4.6F, -2.2F, panelZ(4.6F)};
            float[] c3 = {0.0F, -2.2F, panelZ(0.0F)};
            p.quad(c0, c1, c2, c3, HEAD_CENTER, 0.25F, 0.25F, s > 0 ? 0.5F : 0.0F, 0.75F);
            float[] w0 = c1;
            float[] w1 = {s * 5.45F, -6.5F, -3.6F};
            float[] w2 = {s * 5.45F, -2.4F, -3.6F};
            float[] w3 = c2;
            p.quad(w0, w1, w2, w3, HEAD_CENTER, s > 0 ? 0.4F : 0.5F, 0.25F, s > 0 ? 0.5F : 0.4F, 0.75F);

            // angry brow plate (gold) and its spike
            p.beam(new float[] {s * 5.3F, -7.0F, -4.6F}, new float[] {0.0F, -5.6F, -5.65F}, 0.6F, 0.6F, 0.55F, 0.5F, UP, Y);
            p.beam(new float[] {s * 4.2F, -7.2F, -4.9F}, new float[] {s * 6.6F, -8.8F, -3.8F}, 0.45F, 0.45F, 0.04F, 0.04F, UP, DY);
            // brow stripe in deep green on top of the gold
            p.beam(new float[] {s * 4.8F, -7.5F, -4.7F}, new float[] {s * 0.8F, -6.2F, -5.7F}, 0.3F, 0.3F, 0.3F, 0.3F, UP, DG);
            // bottom frame of the visor
            p.beam(new float[] {s * 5.2F, -2.0F, -4.8F}, new float[] {0.0F, -1.8F, -5.7F}, 0.5F, 0.4F, 0.5F, 0.35F, UP, Y);
            // cheek plate and vent slats
            p.beam(new float[] {s * 5.5F, -2.4F, -3.0F}, new float[] {s * 5.3F, 0.9F, -4.6F}, 0.55F, 0.45F, 0.5F, 0.4F, UP, G);
            for (int i = 0; i < 3; i++) {
                float y = -1.4F + i * 0.9F;
                p.beam(new float[] {s * 5.8F, y, -2.2F - i * 0.15F}, new float[] {s * 5.8F, y, -3.8F - i * 0.1F}, 0.25F, 0.2F, 0.25F, 0.2F, UP, Y);
            }
            // rivets at the visor corners
            p.beam(new float[] {s * 5.0F, -6.7F, -5.2F}, new float[] {s * 5.0F, -6.7F, -5.7F}, 0.28F, 0.28F, 0.28F, 0.28F, UP, LY);
            p.beam(new float[] {s * 5.0F, -2.3F, -5.1F}, new float[] {s * 5.0F, -2.3F, -5.6F}, 0.28F, 0.28F, 0.28F, 0.28F, UP, LY);
        }
        // nose bridge / clypeus
        p.beam(new float[] {0.0F, -5.6F, -5.7F}, new float[] {0.0F, 0.2F, -6.3F}, 0.5F, 0.5F, 0.95F, 0.5F, UP, DG);
        p.beam(new float[] {0.0F, -4.8F, -6.0F}, new float[] {0.0F, -0.4F, -6.6F}, 0.18F, 0.2F, 0.18F, 0.2F, UP, Y);
        // upper lip / mouth guard
        p.beam(new float[] {-2.4F, 0.7F, -5.4F}, new float[] {2.4F, 0.7F, -5.4F}, 0.55F, 0.5F, 0.55F, 0.5F, UP, G);
        p.beam(new float[] {-2.4F, 1.15F, -5.5F}, new float[] {2.4F, 1.15F, -5.5F}, 0.35F, 0.2F, 0.35F, 0.2F, UP, Y);
    }

    private static void drawCrest(Pen p) {
        float[] zs = {-3.2F, 0.0F, 3.2F};
        for (int i = 0; i < zs.length; i++) {
            float z = zs[i];
            p.beam(new float[] {0.0F, -9.0F, z}, new float[] {0.0F, -11.0F - (i == 1 ? 0.6F : 0.0F), z + 1.7F}, 0.5F, 0.5F, 0.06F, 0.06F, UP, i == 1 ? Y : G);
        }
        p.beam(new float[] {0.0F, -9.1F, -4.0F}, new float[] {0.0F, -9.3F, 4.0F}, 0.45F, 0.3F, 0.45F, 0.3F, UP, DG);
    }

    private static final float[] HEAD_CENTER = {0.0F, -4.0F, 0.0F};
    private static final float[] UP = {0.0F, 1.0F, 0.0F};

    private static void drawMandibles(Pen p, float t, float open) {
        // idle: the jaws idly click a little; channelling: they spread wide
        float idleAngle = 0.12F + 0.07F * Mth.sin(t * 0.07F) + 0.04F * Mth.sin(t * 0.33F);
        float angle = Mth.lerp(open, idleAngle, 0.62F);
        for (int k = 0; k < 2; k++) {
            float s = k == 0 ? -1.0F : 1.0F;
            float a = -s * angle;
            float[] root = {s * 2.4F, 0.4F, -5.2F};
            float[][] pts = new float[JAW.length][];
            for (int i = 0; i < JAW.length; i++) {
                pts[i] = jaw(s, root, JAW[i], a);
            }
            for (int i = 0; i < JAW.length - 1; i++) {
                int sw = i >= JAW.length - 3 ? Y : G;
                p.beam(pts[i], pts[i + 1], JAW_W[i], JAW_W[i] * 0.8F, JAW_W[i + 1], JAW_W[i + 1] * 0.8F, new float[] {1.0F, 0.0F, 0.0F}, sw);
            }
            // serrated inner edge
            for (int i = 1; i <= 3; i++) {
                float[] base = pts[i];
                float[] tip = jaw(s, root, new float[] {JAW[i][0] - 1.15F, JAW[i][1] + 0.45F, JAW[i][2] - 0.1F}, a);
                p.beam(base, tip, 0.22F, 0.22F, 0.03F, 0.03F, new float[] {0.0F, 0.0F, 1.0F}, LY);
            }
            // joint cap where the jaw meets the cheek
            p.beam(new float[] {root[0], root[1] - 0.5F, root[2]}, new float[] {root[0], root[1] + 0.5F, root[2]}, 0.7F, 0.7F, 0.7F, 0.7F, UP, DY);
        }
    }

    private static float[] jaw(float s, float[] root, float[] local, float angle) {
        float ox = local[0] * s;
        float oz = local[2];
        float c = Mth.cos(angle);
        float sn = Mth.sin(angle);
        return new float[] {root[0] + ox * c + oz * sn, root[1] + local[1], root[2] - ox * sn + oz * c};
    }

    private static void drawAntennae(Pen p, float t, float open) {
        for (int k = 0; k < 2; k++) {
            float s = k == 0 ? -1.0F : 1.0F;
            float sway = Mth.sin(t * 0.11F + s * 1.3F) * 0.7F;
            float flare = open * 1.6F;   // they perk up and forward while channelling
            float[] p0 = {s * 1.8F, -9.0F, -3.2F};
            float[] p1 = {s * (3.2F + flare * 0.4F), -12.5F, -4.6F - flare * 0.5F};
            float[] p2 = {s * (5.6F + flare) + sway, -15.5F - flare * 0.4F, -7.6F - flare + sway * 0.6F};
            int n = 9;
            float[] prev = p0;
            for (int i = 1; i <= n; i++) {
                float u = i / (float) n;
                float[] cur = bez(p0, p1, p2, u);
                float w = Mth.lerp(u, 0.45F, 0.22F);
                p.beam(prev, cur, w, w, Mth.lerp((i + 1.0F) / (n + 1.0F), 0.45F, 0.22F), Mth.lerp((i + 1.0F) / (n + 1.0F), 0.45F, 0.22F),
                        new float[] {0.0F, 0.0F, 1.0F}, i % 2 == 0 ? Y : G);
                if (i % 3 == 0 && i < n) {
                    // little barbs, like a feathery beetle antenna
                    float[] out = {cur[0] + s * 1.0F, cur[1] - 0.5F, cur[2] - 0.4F};
                    p.beam(cur, out, 0.16F, 0.16F, 0.03F, 0.03F, UP, LG);
                }
                prev = cur;
            }
            // golden bulb at the tip
            float[] tip = prev;
            p.beam(new float[] {tip[0], tip[1] + 0.5F, tip[2]}, new float[] {tip[0], tip[1] - 0.6F, tip[2]}, 0.7F, 0.7F, 0.7F, 0.7F, UP, LY);
        }
    }

    private static float[] bez(float[] a, float[] b, float[] c, float t) {
        float u = 1.0F - t;
        return new float[] {
                u * u * a[0] + 2.0F * u * t * b[0] + t * t * c[0],
                u * u * a[1] + 2.0F * u * t * b[1] + t * t * c[1],
                u * u * a[2] + 2.0F * u * t * b[2] + t * t * c[2]};
    }

    private static void drawEyes(Pen p, float t, float open) {
        int n = 0;
        for (float[] e : EYES) {
            for (int k = 0; k < 2; k++) {
                float s = k == 0 ? -1.0F : 1.0F;
                float flicker = 0.5F + 0.12F * Mth.sin(t * 0.09F + n * 1.7F);
                float br = Mth.lerp(open, flicker, 0.9F + 0.1F * Mth.sin(t * 0.4F + n));
                float cx = s * e[0];
                float cy = e[1];
                float z = panelZ(e[0]) - 0.12F;
                float rad = -s * e[3] * Mth.DEG_TO_RAD;
                float c = Mth.cos(rad);
                float sn = Mth.sin(rad);
                float h = e[2];
                float[][] corners = {{-h, -h}, {h, -h}, {h, h}, {-h, h}};
                float[][] pts = new float[4][];
                for (int i = 0; i < 4; i++) {
                    float x = corners[i][0];
                    float y = corners[i][1];
                    pts[i] = new float[] {cx + x * c - y * sn, cy + x * sn + y * c, z};
                }
                p.quadBright(pts[0], pts[1], pts[2], pts[3], br);
                n++;
            }
        }
    }

    // ------------------------------------------------------------------------------------------ drawing helpers

    private static float[] sub(float[] a, float[] b) {
        return new float[] {a[0] - b[0], a[1] - b[1], a[2] - b[2]};
    }

    private static float[] cross(float[] a, float[] b) {
        return new float[] {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float dot(float[] a, float[] b) {
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    }

    private static float[] norm(float[] a) {
        float l = Mth.sqrt(dot(a, a));
        return l < 1.0E-6F ? new float[] {0.0F, 1.0F, 0.0F} : new float[] {a[0] / l, a[1] / l, a[2] / l};
    }

    private static float[] madd(float[] p, float[] v, float kv, float[] w, float kw) {
        return new float[] {p[0] + v[0] * kv + w[0] * kw, p[1] + v[1] * kv + w[1] * kw, p[2] + v[2] * kv + w[2] * kw};
    }

    /** Draws quads into one vertex buffer. All coordinates are model pixels. */
    private static final class Pen {
        private final VertexConsumer vc;
        private final PoseStack.Pose pose;
        private final int light;

        Pen(VertexConsumer vc, PoseStack.Pose pose, int light) {
            this.vc = vc;
            this.pose = pose;
            this.light = light;
        }

        private void vertex(float[] p, float[] n, float u, float v, float br) {
            vc.addVertex(pose, p[0] / 16.0F, p[1] / 16.0F, p[2] / 16.0F)
                    .setColor(br, br, br, 1.0F)
                    .setUv(u, v)
                    .setOverlay(OverlayTexture.NO_OVERLAY)
                    .setLight(light)
                    .setNormal(pose, n[0], n[1], n[2]);
        }

        /** A textured quad (UV rectangle u0,v0 .. u1,v1), normal pushed away from {@code ref}. */
        void quad(float[] a, float[] b, float[] c, float[] d, float[] ref, float u0, float v0, float u1, float v1) {
            float[] n = norm(cross(sub(b, a), sub(d, a)));
            float[] centre = {(a[0] + b[0] + c[0] + d[0]) * 0.25F, (a[1] + b[1] + c[1] + d[1]) * 0.25F, (a[2] + b[2] + c[2] + d[2]) * 0.25F};
            if (dot(n, sub(centre, ref)) < 0.0F) {
                n = new float[] {-n[0], -n[1], -n[2]};
            }
            vertex(a, n, u0, v0, 1.0F);
            vertex(b, n, u1, v0, 1.0F);
            vertex(c, n, u1, v1, 1.0F);
            vertex(d, n, u0, v1, 1.0F);
        }

        /** The whole eye texture on a forward facing quad. */
        void quadBright(float[] a, float[] b, float[] c, float[] d, float br) {
            float[] n = {0.0F, 0.0F, -1.0F};
            vertex(a, n, 0.0F, 0.0F, br);
            vertex(b, n, 1.0F, 0.0F, br);
            vertex(c, n, 1.0F, 1.0F, br);
            vertex(d, n, 0.0F, 1.0F, br);
        }

        /**
         * A tapered square beam from a to b. {@code hw}/{@code hh} are half sizes at the start (A) and end (B);
         * {@code hint} picks which way "width" points. Painted with one flat swatch of the atlas.
         */
        void beam(float[] a, float[] b, float hwA, float hhA, float hwB, float hhB, float[] hint, int swatch) {
            float[] u = norm(sub(b, a));
            float[] v = cross(hint, u);
            if (dot(v, v) < 1.0E-4F) {
                v = cross(new float[] {1.0F, 0.0F, 0.0F}, u);
                if (dot(v, v) < 1.0E-4F) {
                    v = cross(new float[] {0.0F, 0.0F, 1.0F}, u);
                }
            }
            v = norm(v);
            float[] w = norm(cross(u, v));
            float[][] ca = {madd(a, v, hwA, w, hhA), madd(a, v, -hwA, w, hhA), madd(a, v, -hwA, w, -hhA), madd(a, v, hwA, w, -hhA)};
            float[][] cb = {madd(b, v, hwB, w, hhB), madd(b, v, -hwB, w, hhB), madd(b, v, -hwB, w, -hhB), madd(b, v, hwB, w, -hhB)};
            float[] mid = {(a[0] + b[0]) * 0.5F, (a[1] + b[1]) * 0.5F, (a[2] + b[2]) * 0.5F};
            float su = ((swatch % 8) * 4 + 2) / 64.0F;
            float sv = 2.0F / 32.0F;
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) % 4;
                quad(ca[i], ca[j], cb[j], cb[i], mid, su, sv, su, sv);
            }
            quad(ca[0], ca[1], ca[2], ca[3], mid, su, sv, su, sv);
            quad(cb[0], cb[1], cb[2], cb[3], mid, su, sv, su, sv);
        }
    }
}
