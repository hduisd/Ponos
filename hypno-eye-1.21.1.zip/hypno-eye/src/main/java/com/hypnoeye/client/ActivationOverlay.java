package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Screen-space eye that blooms in the middle of the screen for the player who activates the ability. */
public final class ActivationOverlay {
    private static final ResourceLocation SPIRAL = HypnoEye.id("textures/entity/hypno_spiral.png");
    private static final ResourceLocation PUPIL = HypnoEye.id("textures/entity/hypno_pupil.png");

    public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }
        float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
        float p = ClientAnimState.activationProgress(mc.player, partial);
        if (p < 0.0F) {
            return;
        }
        float fadeIn = ClientAnimState.smooth(p / 0.2F);
        float fadeOut = 1.0F - ClientAnimState.smooth((p - 0.55F) / 0.45F);
        float fade = fadeIn * fadeOut;

        int w = g.guiWidth();
        int h = g.guiHeight();
        int size = (int) (Math.min(w, h) * (0.30F + 0.85F * p));
        float t = (mc.player.tickCount + partial);
        int frame = ((int) (t / 3.0F)) & 3;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        int washAlpha = (int) (0.10F * fade * 255.0F); // soft pink wash over the whole screen
        g.fill(0, 0, w, h, (washAlpha << 24) | 0xE0006A);

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(w / 2.0F, h / 2.0F, 0.0F);
        ps.mulPose(Axis.ZP.rotationDegrees(p * 540.0F));
        g.setColor(1.0F, 1.0F, 1.0F, 0.55F * fade);
        g.blit(SPIRAL, -size / 2, -size / 2, 0.0F, 0.0F, size, size, size, size);
        ps.popPose();

        ps.pushPose();
        ps.translate(w / 2.0F, h / 2.0F, 0.0F);
        g.setColor(1.0F, 1.0F, 1.0F, 0.85F * fade);
        g.blit(PUPIL, -size / 2, -size / 2, (float) (frame * size), 0.0F, size, size, size * 4, size);
        ps.popPose();

        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    private ActivationOverlay() {}
}
