package com.hypnoeye.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.hypnoeye.registry.ModEffects;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tiny client-side animation bookkeeping. The hypnosis itself is NOT stored here: it is read from the synced
 * MobEffect, so every player sees it. Here we only remember when an animation started.
 */
public final class ClientAnimState {
    /** Length of the eye activation animation in ticks. */
    public static final float ACTIVATION_TICKS = 40.0F;

    private static final Map<Integer, Long> ACTIVATION = new HashMap<>();
    private static final Map<Integer, Long> HYPNO_SINCE = new HashMap<>();

    public static void startActivation(int entityId) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level != null) {
            ACTIVATION.put(entityId, level.getGameTime());
        }
    }

    /** @return 0..1 progress of the activation animation of this entity, or -1 when it is not playing. */
    public static float activationProgress(Entity entity, float partialTick) {
        Long start = ACTIVATION.get(entity.getId());
        if (start == null) {
            return -1.0F;
        }
        float p = (entity.level().getGameTime() + partialTick - start) / ACTIVATION_TICKS;
        if (p >= 1.0F) {
            ACTIVATION.remove(entity.getId());
            return -1.0F;
        }
        return Math.max(p, 0.0F);
    }

    /** Smooth fade-in right after the hypnosis starts and fade-out during its last second. */
    public static float hypnoAlpha(LivingEntity entity, MobEffectInstance effect, float partialTick) {
        long now = entity.level().getGameTime();
        long since = HYPNO_SINCE.computeIfAbsent(entity.getId(), k -> now);
        float fadeIn = Mth.clamp((now + partialTick - since) / 15.0F, 0.0F, 1.0F);
        float fadeOut = effect.isInfiniteDuration() ? 1.0F : Mth.clamp((effect.getDuration() - partialTick) / 20.0F, 0.0F, 1.0F);
        return smooth(Math.min(fadeIn, fadeOut));
    }

    public static void forget(int entityId) {
        HYPNO_SINCE.remove(entityId);
    }

    public static void clearAll() {
        ACTIVATION.clear();
        HYPNO_SINCE.clear();
    }

    /** Drops records of entities that are gone or no longer hypnotized (called every few seconds). */
    public static void cleanup(ClientLevel level) {
        Iterator<Integer> it = HYPNO_SINCE.keySet().iterator();
        while (it.hasNext()) {
            Entity e = level.getEntity(it.next());
            if (!(e instanceof LivingEntity living) || !living.hasEffect(ModEffects.HYPNOSIS)) {
                it.remove();
            }
        }
    }

    public static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private ClientAnimState() {}
}
