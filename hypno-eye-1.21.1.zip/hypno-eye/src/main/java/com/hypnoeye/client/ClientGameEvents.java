package com.hypnoeye.client;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.network.HoldPayload;
import com.hypnoeye.registry.ModItems;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = HypnoEye.MODID, value = Dist.CLIENT)
public final class ClientGameEvents {
    /** True while we told the server that the key is held. */
    private static boolean holding = false;
    private static boolean wasDown = false;
    private static int beatTimer = 0;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            ClientAnimState.clearAll();
            holding = false;
            wasDown = false;
            return;
        }
        boolean down = ClientKeys.ACTIVATE.isDown();
        ItemStack vest = mc.player.getItemBySlot(EquipmentSlot.CHEST);
        boolean wearing = vest.is(ModItems.HYPNO_SCREENS.get()) && !mc.player.isSpectator();

        if (down && !wasDown && wearing) {
            if (mc.player.getCooldowns().isOnCooldown(vest.getItem())) {
                mc.player.displayClientMessage(Component.translatable("message.hypnoeye.cooldown"), true);
            } else {
                // the client only asks; the server checks everything again
                PacketDistributor.sendToServer(new HoldPayload(true));
                holding = true;
                beatTimer = 0;
            }
        } else if (holding) {
            if (!down || !wearing) {
                PacketDistributor.sendToServer(new HoldPayload(false));
                holding = false;
            } else if (++beatTimer >= 5) { // heartbeat: "still held"
                PacketDistributor.sendToServer(new HoldPayload(true));
                beatTimer = 0;
            }
        }
        wasDown = down;

        if (mc.level.getGameTime() % 100L == 0L) {
            ClientAnimState.cleanup(mc.level);
        }
    }

    private ClientGameEvents() {}
}
