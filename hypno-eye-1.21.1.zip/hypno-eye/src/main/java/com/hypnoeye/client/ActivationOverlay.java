package com.hypnoeye.client;

import java.util.Random;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** While the ability plays, the screen gets a very light red tint with thin, small flickering electric sparks. */
public final class ActivationOverlay {
    private static final int BOLTS = 16;

    public static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }
        float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
        float fade = ClientAnimState.channelOpen(mc.player, partial);
        if (fade <= 0.0F) {
            return;
        }
        int w = g.guiWidth();
        int h = g.guiHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // very light red tint
        int tint = (int) (0.12F * fade * 255.0F);
        g.fill(0, 0, w, h, (tint << 24) | 0xE00020);

        // thin zigzag sparks; they re-roll every 3 ticks, which makes them flicker like electricity
        int step = (int) ((mc.player.tickCount + partial) / 3.0F);
        for (int i = 0; i < BOLTS; i++) {
            Random r = new Random(i * 7919L + step * 104729L);
            int x = r.nextInt(Math.max(1, w));
            int y = r.nextInt(Math.max(1, h));
            int segments = 4 + r.nextInt(4);
            float a = fade * (0.35F + 0.45F * r.nextFloat());
            int color = ((int) (a * 255.0F) << 24) | 0xFF9AC8;
            for (int s = 0; s < segments; s++) {
                int dy = 3 + r.nextInt(4);
                int dx = r.nextInt(7) - 3;
                g.fill(x, y, x + 1, y + dy, color);         // 1px wide vertical piece
                y += dy;
                if (dx != 0) {
                    g.fill(Math.min(x, x + dx), y, Math.max(x, x + dx) + 1, y + 1, color); // sideways jag
                    x += dx;
                }
            }
        }

        RenderSystem.disableBlend();
    }

    private ActivationOverlay() {}
}
