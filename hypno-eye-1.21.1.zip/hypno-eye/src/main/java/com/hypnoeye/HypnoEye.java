package com.hypnoeye;

import com.hypnoeye.registry.ModArmor;
import com.hypnoeye.registry.ModEffects;
import com.hypnoeye.registry.ModItems;
import com.hypnoeye.registry.ModParticles;
import com.hypnoeye.registry.ModSounds;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(HypnoEye.MODID)
public class HypnoEye {
    public static final String MODID = "hypnoeye";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public HypnoEye(IEventBus modBus, ModContainer container) {
        ModArmor.MATERIALS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        container.registerConfig(ModConfig.Type.COMMON, HypnoConfig.SPEC);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.HYPNO_SCREENS.get());
            event.accept(ModItems.BUG_MASK.get());
        }
    }
}
