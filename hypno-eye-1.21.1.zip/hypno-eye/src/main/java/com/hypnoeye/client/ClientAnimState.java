package com.hypnoeye.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.hypnoeye.registry.ModEffects;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tiny client-side animation bookkeeping. The hypnosis itself is NOT stored here: it is read from the synced
 * MobEffect, so every player sees it. Here we only remember when an animation started.
 */
public final class ClientAnimState {
    private static final Map<Integer, Long> STARTED = new HashMap<>();
    private static final Map<Integer, Long> STOPPED = new HashMap<>();
    private static final Map<Integer, Long> HYPNO_SINCE = new HashMap<>();
    private static final float OPEN_TICKS = 10.0F;

    /** The server says an entity started (true) or stopped (false) channeling its Hypno Eye. */
    public static void setChannel(int entityId, boolean active) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        long now = level.getGameTime();
        if (active) {
            STARTED.put(entityId, now);
            STOPPED.remove(entityId);
            Entity caster = level.getEntity(entityId);
            if (caster != null) {
                mc.getSoundManager().play(new HypnoLoopSound(caster));
            }
        } else if (STARTED.containsKey(entityId) && !STOPPED.containsKey(entityId)) {
            STOPPED.put(entityId, now);
        }
    }

    public static boolean isChannelActive(Entity entity) {
        return STARTED.containsKey(entity.getId()) && !STOPPED.containsKey(entity.getId());
    }

    /** @return 0..1 how far the eye is open: eases in when the channel starts, eases out after it stops. */
    public static float channelOpen(Entity entity, float partialTick) {
        Long start = STARTED.get(entity.getId());
        if (start == null) {
            return 0.0F;
        }
        float now = entity.level().getGameTime() + partialTick;
        float up = smooth((now - start) / OPEN_TICKS);
        Long stop = STOPPED.get(entity.getId());
        if (stop == null) {
            return up;
        }
        if (now - stop >= OPEN_TICKS) {
            STARTED.remove(entity.getId());
            STOPPED.remove(entity.getId());
            return 0.0F;
        }
        return Math.min(up, 1.0F - smooth((now - stop) / OPEN_TICKS));
    }

    /** Smooth fade-in right after the hypnosis starts and fade-out during its last second. */
    public static float hypnoAlpha(LivingEntity entity, MobEffectInstance effect, float partialTick) {
        long now = entity.level().getGameTime();
        long since = HYPNO_SINCE.computeIfAbsent(entity.getId(), k -> now);
        float fadeIn = Mth.clamp((now + partialTick - since) / 15.0F, 0.0F, 1.0F);
        float fadeOut = effect.isInfiniteDuration() ? 1.0F : Mth.clamp((effect.getDuration() - partialTick) / 20.0F, 0.0F, 1.0F);
        return smooth(Math.min(fadeIn, fadeOut));
    }

    public static void forget(int entityId) {
        HYPNO_SINCE.remove(entityId);
    }

    public static void clearAll() {
        STARTED.clear();
        STOPPED.clear();
        HYPNO_SINCE.clear();
    }

    /** Drops records of entities that are gone or no longer hypnotized (called every few seconds). */
    public static void cleanup(ClientLevel level) {
        STARTED.keySet().removeIf(id -> level.getEntity(id) == null);
        STOPPED.keySet().removeIf(id -> !STARTED.containsKey(id));
        Iterator<Integer> it = HYPNO_SINCE.keySet().iterator();
        while (it.hasNext()) {
            Entity e = level.getEntity(it.next());
            if (!(e instanceof LivingEntity living) || !living.hasEffect(ModEffects.HYPNOSIS)) {
                it.remove();
            }
        }
    }

    public static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private ClientAnimState() {}
}
