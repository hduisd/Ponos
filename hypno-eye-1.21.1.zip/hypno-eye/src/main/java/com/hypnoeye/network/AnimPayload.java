package com.hypnoeye.network;

import com.hypnoeye.HypnoEye;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> clients tracking the caster: start the activation animation of that entity's Hypno Eye. */
public record AnimPayload(int entityId) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AnimPayload> TYPE = new CustomPacketPayload.Type<>(HypnoEye.id("anim"));
    public static final StreamCodec<ByteBuf, AnimPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, AnimPayload::entityId,
            AnimPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
