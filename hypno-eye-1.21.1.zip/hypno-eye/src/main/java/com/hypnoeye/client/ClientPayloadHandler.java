package com.hypnoeye.client;

import com.hypnoeye.network.AnimPayload;

import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class ClientPayloadHandler {
    public static void handleAnim(AnimPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientAnimState.setChannel(payload.entityId(), payload.active()));
    }

    private ClientPayloadHandler() {}
}
