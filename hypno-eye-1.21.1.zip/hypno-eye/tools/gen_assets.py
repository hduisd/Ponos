#!/usr/bin/env python3
"""Generates all textures and sounds of the Hypno Eye mod (style: dark olive-green eye, gold rings, white zigzag pupil).
Run from the project root:  python3 tools/gen_assets.py   (needs Pillow + numpy + ffmpeg with libvorbis)"""
import math, random, subprocess, wave, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "hypnoeye")
PINK = (78, 90, 26)      # dark olive green (kept the name PINK for the main fill)
DEEP = (46, 54, 16)
BLACK = (14, 12, 6)      # near-black bezel
GOLD = (214, 165, 32)
GOLD_HI = (255, 214, 90)
WHITE = (255, 255, 255)
SS = 4  # supersampling


def out(*p):
    path = os.path.join(ROOT, *p)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


# ---------------------------------------------------------------- spiral (rotating iris), 128x128
def spiral(size=128):
    n = size * SS
    ys, xs = np.mgrid[0:n, 0:n]
    x = (xs + 0.5) / n * 2 - 1
    y = (ys + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    img = np.zeros((n, n, 4), dtype=np.float32)
    img[..., :3] = PINK
    # spiral band: 3 arms, black stripes
    v = (r * 3.2 - th / (2 * math.pi) * 3.0) % 1.0
    band = (v < 0.42) & (r > 0.34) & (r < 0.86)
    img[band, :3] = GOLD
    # solid black outer ring and inner ring around the pupil
    outer = (r > 0.88) & (r <= 1.0)
    inner = (r > 0.27) & (r < 0.34)
    img[outer, :3] = GOLD
    img[inner, :3] = GOLD
    # darker pink centre
    img[r < 0.27, :3] = DEEP
    img[..., 3] = np.where(r <= 1.0, 255, 0)
    im = Image.fromarray(img.astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)
    return im


# ---------------------------------------------------------------- zigzag pupil frames (4 frames strip)
def pupil_strip(fs=64, frames=4):
    rnd = random.Random(7)
    strip = Image.new("RGBA", (fs * frames, fs), (0, 0, 0, 0))
    ys = [0.08, 0.22, 0.34, 0.46, 0.56, 0.68, 0.80, 0.93]
    for f in range(frames):
        big = fs * SS
        mask = Image.new("L", (big, big), 0)
        d = ImageDraw.Draw(mask)
        pts = []
        for i, yy in enumerate(ys):
            amp = 0.0 if i in (0, len(ys) - 1) else rnd.uniform(0.10, 0.30) * (1 if i % 2 else -1)
            pts.append((big * (0.5 + amp * (0.6 if f % 2 else 1.0)), big * yy))
        d.line(pts, fill=255, width=int(big * 0.05), joint="curve")
        glow = mask.filter(ImageFilter.GaussianBlur(big * 0.035))
        glow = glow.point(lambda v: min(255, int(v * 1.6)))
        frame = Image.new("RGBA", (big, big), (255, 214, 90, 0))
        frame.putalpha(glow)
        core = Image.new("RGBA", (big, big), WHITE + (0,))
        core.putalpha(mask)
        frame = Image.alpha_composite(frame, core)
        frame = frame.resize((fs, fs), Image.LANCZOS)
        strip.paste(frame, (f * fs, 0))
    return strip


# ---------------------------------------------------------------- item icon 16x16 (hand-pixelled by formula)
def item_icon():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / 7.6, (y - cy) / 7.6
            r = math.hypot(dx, dy)
            # slightly eye-shaped (wider than tall)
            r = math.hypot(dx * 0.92, dy * 1.12)
            if r > 1.0:
                continue
            if r > 0.82:
                c = GOLD
            elif 0.46 < r < 0.62:
                c = GOLD
            elif r < 0.46:
                c = DEEP
            else:
                c = PINK
            px[x, y] = c + (255,)
    # zigzag pupil
    zig = [(8, 2), (7, 4), (9, 6), (6, 8), (9, 10), (7, 11), (8, 13)]
    d = ImageDraw.Draw(im)
    for a, b in zip(zig, zig[1:]):
        d.line([a, b], fill=WHITE + (255,))
    # highlight pixel
    px[4, 4] = GOLD_HI + (255,)
    return im


# ---------------------------------------------------------------- pixel lens animation (worn eye): 12 frames of 16x16
def lens_strip(frames=12, n=16, round_mask=False):
    """Pixel-art rectangular "screen" version of the reference video: black rings are born in the centre, expand outwards, get thinner
    and fade, while a white zigzag pupil jitters from frame to frame. Strip of `frames` frames, each n x n."""
    rnd = random.Random(11)
    strip = Image.new("RGBA", (n * frames, n), (0, 0, 0, 0))
    c = (n - 1) / 2.0
    for f in range(frames):
        im = Image.new("RGBA", (n, n), (0, 0, 0, 0))
        px = im.load()
        for y in range(n):
            for x in range(n):
                edge = min(x, n - 1 - x, y, n - 1 - y)
                r = math.hypot(x - c, y - c)
                if round_mask:
                    if r > n / 2.0 - 0.2:                        # round version for the olive holes
                        continue
                elif min(x, n - 1 - x) + min(y, n - 1 - y) < 2:   # cut the corners: little rounded screen
                    continue
                if round_mask:
                    col = BLACK if r > n / 2.0 - 1.4 else PINK   # dark rim instead of the cyan outline
                    for k in range(2):
                        ph = (f / frames + k * 0.5) % 1.0
                        rad = 0.6 + ph * 5.4
                        width = 1.6 * (1.0 - ph) + 1.0
                        if r < n / 2.0 - 1.4 and abs(r - rad) < width / 2.0:
                            col = GOLD
                    px[x, y] = col + (255,)
                    continue
                if edge == 0:
                    col = (0, 230, 230)                          # thin cyan screen outline
                elif edge == 1:
                    col = BLACK                                  # bezel
                else:
                    col = PINK
                    for k in range(2):                           # two expanding rings, half a cycle apart
                        ph = (f / frames + k * 0.5) % 1.0
                        rad = 0.6 + ph * 5.4
                        width = 1.6 * (1.0 - ph) + 1.0
                        if abs(r - rad) < width / 2.0:
                            col = GOLD
                px[x, y] = col + (255,)
        # zigzag pupil: vertical lightning, 1 px wide, jitters every frame
        d = ImageDraw.Draw(im)
        cx = int(c + 0.5)
        pts = [(cx, 2)]
        sign = rnd.choice([-1, 1])
        for yy in (4, 6, 8, 10, 12):
            pts.append((cx + sign * rnd.choice([1, 2, 2, 3]), yy))
            sign = -sign
        pts.append((cx, 14))
        for a_, b_ in zip(pts, pts[1:]):
            d.line([a_, b_], fill=WHITE + (255,))
        strip.paste(im, (f * n, 0))
    return strip


def screens_icon():
    """Chest piece icon: dark vest with cyan trim and two small olive screens on wires."""
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    CY = (0, 230, 230)
    # vest body
    for y in range(3, 15):
        for x in range(4, 12):
            if y < 5 and 6 <= x <= 9:
                continue  # neck hole
            px[x, y] = (24, 14, 34, 255)
    for y in range(3, 7):                       # shoulders
        for x in (3, 12):
            px[x, y] = (24, 14, 34, 255)
    for y in range(3, 15):                      # cyan trim
        px[4, y] = CY + (255,)
        px[11, y] = CY + (255,)
    for x in range(4, 12):
        px[x, 14] = CY + (255,)
    # two floating screens on the sides
    def screen(x0, y0):
        for y in range(y0, y0 + 4):
            for x in range(x0, x0 + 4):
                edge = x in (x0, x0 + 3) or y in (y0, y0 + 3)
                px[x, y] = (CY if edge else PINK) + (255,)
        px[x0 + 1, y0 + 1] = GOLD + (255,)
        px[x0 + 2, y0 + 2] = WHITE + (255,)
    screen(0, 0)
    screen(12, 1)
    return im


def olive_skin(w=32, h=16):
    """Olive skin: dark olive green with mottling and a lighter sheen band (one strip wraps the whole olive)."""
    rnd = np.random.RandomState(21)
    img = np.zeros((h, w, 4), dtype=np.uint8)
    for y in range(h):
        for x in range(w):
            base = np.array([84, 98, 34], dtype=float)
            base *= 0.82 + 0.36 * rnd.rand()
            if rnd.rand() < 0.07:
                base = np.array([54, 62, 22], dtype=float)         # dark speckles
            sheen = max(0.0, 1.0 - abs(y - h * 0.3) / (h * 0.22))  # lighter band near the pole
            base += sheen * np.array([22, 24, 8])
            img[y, x] = (*np.clip(base, 0, 255).astype(np.uint8), 255)
    return Image.fromarray(img, "RGBA")


def olive_leaf(w=8, h=32):
    """Narrow olive leaf (tip at the top, stalk at the bottom): green on the left, silvery underside on the right, light midrib."""
    rnd = np.random.RandomState(5)
    img = np.zeros((h, w, 4), dtype=np.uint8)
    for y in range(h):
        v = y / (h - 1)
        half = 3.7 * math.sin(math.pi * (v ** 0.85))
        for x in range(w):
            dx = x + 0.5 - w / 2.0
            if abs(dx) > half or half < 0.35:
                continue
            if abs(dx) < 0.55:
                col = np.array([178, 186, 130], dtype=float)       # midrib
            elif dx < 0:
                col = np.array([78, 100, 44], dtype=float)         # green upper side
            else:
                col = np.array([140, 152, 112], dtype=float)       # silvery underside
            col *= 0.93 + 0.14 * rnd.rand()
            img[y, x] = (*np.clip(col, 0, 255).astype(np.uint8), 255)
    return Image.fromarray(img, "RGBA")



# ---------------------------------------------------------------- Bean Beetle Mask textures
SWATCHES = [(22, 60, 34), (46, 104, 52), (110, 170, 70), (150, 110, 20), (214, 165, 32), (255, 224, 120), (16, 18, 14), (90, 100, 80)]


def hex_visor_tile(w=32, h=16):
    """Faceted compound-eye tile: small hexagon cells shimmering from green to gold, dark seams."""
    rnd = random.Random(33)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    px = im.load()
    size = 2.6
    cells = {}
    for y in range(h):
        for x in range(w):
            # pointy-top hex grid, axial coordinates
            fx = (x + 0.5) / (size * math.sqrt(3))
            fy = (y + 0.5) / (size * 1.5)
            q = fx - fy / 3.0 * 0.0
            r = fy
            rr = round(r)
            qq = round(fx - (rr % 2) * 0.5)
            cx = (qq + (rr % 2) * 0.5) * size * math.sqrt(3)
            cy = rr * size * 1.5
            d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
            key = (qq, rr)
            if key not in cells:
                t = rnd.random()
                cells[key] = t
            t = cells[key]
            if d > size * 1.12:
                col = SWATCHES[0]                        # seam
            else:
                a = np.array(SWATCHES[1], dtype=float)
                b = np.array(SWATCHES[4], dtype=float)
                c = np.array(SWATCHES[2], dtype=float)
                col = a * (1 - t) + b * t
                col = col * (1.0 - 0.35 * d / size) + c * 0.15 * (1 - d / size)
                col = tuple(int(max(0, min(255, v))) for v in col)
            px[x, y] = tuple(col) + (255,)
    return im


def parts_atlas():
    """64x32: swatches (8 of 4x4 px) in the top strip, hex visor tile at (0,8)."""
    im = Image.new("RGBA", (64, 32), (0, 0, 0, 255))
    px = im.load()
    for i, c in enumerate(SWATCHES):
        for y in range(4):
            for x in range(4):
                px[i * 4 + x, y] = c + (255,)
    im.paste(hex_visor_tile(), (0, 8))
    return im


def bug_eye(size=16):
    """Glowing faceted spider eye: gold ring, 8 shimmering sectors, bright lime core with a dark slit and a highlight."""
    n = size * 8
    ys, xs = np.mgrid[0:n, 0:n]
    x = (xs + 0.5) / n * 2 - 1
    y = (ys + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    img = np.zeros((n, n, 4), dtype=np.float32)
    sector = (np.floor((th + math.pi) / (2 * math.pi) * 8).astype(int)) % 2
    lime = np.array([150, 235, 80], dtype=np.float32)
    green = np.array([60, 150, 50], dtype=np.float32)
    img[..., :3] = np.where(sector[..., None] == 0, lime, green)
    ring = r > 0.78
    img[ring, :3] = np.array(SWATCHES[4], dtype=np.float32)
    outer = r > 0.92
    img[outer, :3] = np.array(SWATCHES[3], dtype=np.float32)
    core = r < 0.42
    img[core, :3] = np.array([210, 255, 140], dtype=np.float32)
    slit = (np.abs(x) < 0.09) & (np.abs(y) < 0.3)
    img[slit, :3] = np.array([14, 30, 8], dtype=np.float32)
    glint = (np.hypot(x + 0.32, y + 0.34) < 0.12)
    img[glint, :3] = 255
    img[..., 3] = np.where(r <= 1.0, 255, 0)
    return Image.fromarray(img.astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)


def armor_layer():
    """textures/models/armor/bug_mask_layer_1.png (64x32): head UV area only. Green plates with gold trim."""
    rnd = np.random.RandomState(8)
    im = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    px = im.load()

    def fill(x0, y0, x1, y1, base):
        for yy in range(y0, y1):
            for xx in range(x0, x1):
                k = 0.9 + 0.2 * rnd.rand()
                px[xx, yy] = tuple(int(min(255, v * k)) for v in base) + (255,)

    G_, DG_, Y_, DY_ = SWATCHES[1], SWATCHES[0], SWATCHES[4], SWATCHES[3]
    fill(8, 0, 16, 8, G_)        # top
    fill(16, 0, 24, 8, DG_)      # bottom
    fill(0, 8, 8, 16, G_)        # right side
    fill(8, 8, 16, 16, DG_)      # front
    fill(16, 8, 24, 16, G_)      # left side
    fill(24, 8, 32, 16, DG_)     # back
    for yy in range(8, 16):      # gold lower rim on every side face
        for xx in range(0, 32):
            if yy == 15:
                px[xx, yy] = Y_ + (255,)
    for xx in range(0, 32):      # gold brow line
        px[xx, 9] = DY_ + (255,)
    for yy in range(0, 8):       # gold stripe along the top
        px[11, yy] = Y_ + (255,)
        px[12, yy] = Y_ + (255,)
    for k in range(8):           # rivets
        for (bx, by) in ((1, 10), (6, 10), (17, 10), (22, 10), (9, 14), (14, 14)):
            px[bx, by] = SWATCHES[5] + (255,)
    for xx in range(24, 32):     # hex pattern on the back
        for yy in range(10, 15):
            if (xx + yy) % 3 == 0:
                px[xx, yy] = Y_ + (255,)
    return im


def bug_mask_icon():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    G_, DG_, Y_, LY_, BK_ = SWATCHES[1], SWATCHES[0], SWATCHES[4], SWATCHES[5], SWATCHES[6]
    # helmet dome
    d.rectangle([3, 4, 12, 11], fill=G_)
    d.rectangle([4, 3, 11, 3], fill=G_)
    d.point([(3, 4), (12, 4)], fill=(0, 0, 0, 0))
    # gold crest + brow
    d.line([(8, 1), (8, 3)], fill=Y_)
    d.line([(3, 5), (7, 6)], fill=Y_)
    d.line([(12, 5), (8, 6)], fill=Y_)
    # faceted visor
    d.rectangle([4, 6, 11, 9], fill=DG_)
    for xx in range(4, 12):
        for yy in range(6, 10):
            if (xx + yy) % 2 == 0:
                im.putpixel((xx, yy), (80, 150, 60, 255))
    # eyes
    for (ex, ey) in ((5, 8), (6, 8), (9, 8), (10, 8)):
        im.putpixel((ex, ey), LY_ + (255,))
    im.putpixel((4, 7), Y_ + (255,)); im.putpixel((11, 7), Y_ + (255,))
    # antennae
    d.line([(4, 3), (2, 0)], fill=Y_)
    d.line([(11, 3), (13, 0)], fill=Y_)
    im.putpixel((2, 0), LY_ + (255,)); im.putpixel((13, 0), LY_ + (255,))
    # mandibles
    d.line([(5, 11), (4, 14)], fill=Y_); d.line([(4, 14), (6, 15)], fill=Y_)
    d.line([(10, 11), (11, 14)], fill=Y_); d.line([(11, 14), (9, 15)], fill=Y_)
    d.line([(6, 11), (9, 11)], fill=DG_)
    return im


def effect_icon():
    im = Image.new("RGBA", (18, 18), (0, 0, 0, 0))
    ic = item_icon().resize((16, 16), Image.NEAREST)
    im.paste(ic, (1, 1))
    return im


def particle_ring(size=16):
    n = size * 8
    ys, xs = np.mgrid[0:n, 0:n]
    x = (xs + 0.5) / n * 2 - 1
    y = (ys + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    img = np.zeros((n, n, 4), dtype=np.float32)
    img[..., :3] = PINK
    ring = (r > 0.55) & (r < 0.95)
    inner = (r > 0.22) & (r < 0.36)
    img[ring | inner, :3] = GOLD
    # white glint on top of ring
    glint = ((r > 0.62) & (r < 0.88)) & (np.arctan2(y, x) > -2.4) & (np.arctan2(y, x) < -1.5)
    img[glint, :3] = GOLD_HI
    img[..., 3] = np.where(((r > 0.55) & (r < 0.95)) | ((r > 0.22) & (r < 0.36)), 255, 0)
    return Image.fromarray(img.astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)


# ---------------------------------------------------------------- sounds
SR = 44100


def save_ogg(name, data):
    data = np.clip(data, -1, 1)
    wav = out("sounds", name + ".wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((data * 32000).astype("<i2").tobytes())
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5", out("sounds", name + ".ogg")], check=True)
    os.remove(wav)


def t_arr(sec):
    return np.linspace(0, sec, int(SR * sec), endpoint=False)


def env(t, a, d):
    e = np.minimum(t / a, 1.0) * np.exp(-t / d)
    return e


def echo(x, delay=0.11, gain=0.35, n=3):
    y = x.copy()
    for i in range(1, n + 1):
        s = int(SR * delay * i)
        y[s:] += x[:-s] * (gain ** i)
    return y


def snd_activate():
    sec = 1.5
    t = t_arr(sec)
    freq = 180 + 760 * (t / sec) ** 1.6
    phase = 2 * np.pi * np.cumsum(freq) / SR
    tone = np.sin(phase + 2.2 * np.sin(2 * np.pi * 9 * t))
    trem = 0.65 + 0.35 * np.sin(2 * np.pi * (6 + 10 * t / sec) * t)
    shimmer = np.sin(2 * np.pi * 2400 * t + 5 * np.sin(2 * np.pi * 31 * t)) * 0.12 * (t / sec)
    rnd = np.random.RandomState(3)
    noise = rnd.randn(len(t)) * 0.05 * np.sin(np.pi * t / sec)
    amp = np.minimum(t / 0.12, 1) * np.minimum((sec - t) / 0.35, 1)
    x = (tone * trem * 0.5 + shimmer + noise) * amp
    return echo(x, 0.13, 0.3, 3) * 0.7


def snd_success():
    sec = 1.1
    t = t_arr(sec)
    a = np.sin(2 * np.pi * 523.25 * t) * env(t, 0.005, 0.28)
    b = np.sin(2 * np.pi * 783.99 * t * (1 + 0.004 * np.sin(2 * np.pi * 7 * t))) * env(t, 0.005, 0.35)
    low = np.sin(2 * np.pi * 110 * t * (1 - 0.25 * t)) * env(t, 0.003, 0.2)
    rnd = np.random.RandomState(5)
    zap = rnd.randn(len(t)) * env(t, 0.001, 0.025) * 0.5
    zap = zap - np.concatenate([[0], zap[:-1]]) * 0.9  # high-pass-ish
    x = 0.45 * a + 0.35 * b + 0.5 * low + 0.6 * zap
    return echo(x, 0.09, 0.3, 3) * 0.75


def snd_end():
    sec = 0.95
    t = t_arr(sec)
    freq = 640 * np.exp(-3.2 * t / sec) + 70
    phase = 2 * np.pi * np.cumsum(freq) / SR
    x = np.sin(phase + 1.2 * np.sin(2 * np.pi * 5 * t)) * np.exp(-t / 0.4) * np.minimum(t / 0.02, 1)
    pop = np.sin(2 * np.pi * 90 * t) * env(t, 0.002, 0.05)
    return echo(0.55 * x + 0.5 * pop, 0.1, 0.25, 2) * 0.8


if __name__ == "__main__":
    spiral().save(out("textures", "entity", "hypno_spiral.png"))
    pupil_strip().save(out("textures", "entity", "hypno_pupil.png"))
    screens_icon().save(out("textures", "item", "hypno_screens.png"))
    lens_strip().save(out("textures", "entity", "hypno_lens.png"))
    lens_strip(round_mask=True).save(out("textures", "entity", "hypno_lens_round.png"))
    olive_skin().save(out("textures", "entity", "olive_skin.png"))
    parts_atlas().save(out("textures", "entity", "bug_mask_parts.png"))
    bug_eye().save(out("textures", "entity", "bug_eye.png"))
    armor_layer().save(out("textures", "models", "armor", "bug_mask_layer_1.png"))
    bug_mask_icon().save(out("textures", "item", "bug_mask.png"))
    olive_leaf().save(out("textures", "entity", "olive_leaf.png"))
    effect_icon().save(out("textures", "mob_effect", "hypnosis.png"))
    particle_ring().save(out("textures", "particle", "hypno_ring.png"))
    # the only sound (hypno_loop.ogg) is the user's own, cut from his video; it is not generated here
    print("assets generated")
