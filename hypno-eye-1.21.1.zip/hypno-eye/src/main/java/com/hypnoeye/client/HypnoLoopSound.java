package com.hypnoeye.client;

import com.hypnoeye.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;

/** The looping hypnosis sound; follows the caster and stops by itself when the channel ends. */
public class HypnoLoopSound extends AbstractTickableSoundInstance {
    private final int entityId;

    public HypnoLoopSound(Entity caster) {
        super(ModSounds.LOOP.get(), SoundSource.PLAYERS, RandomSource.create());
        this.entityId = caster.getId();
        this.looping = true;
        this.delay = 0;
        this.volume = 0.6F;
        this.pitch = 1.0F;
        this.x = caster.getX();
        this.y = caster.getEyeY();
        this.z = caster.getZ();
    }

    @Override
    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        Entity caster = mc.level == null ? null : mc.level.getEntity(this.entityId);
        if (caster == null || !caster.isAlive() || !ClientAnimState.isChannelActive(caster)) {
            this.stop();
            return;
        }
        this.x = caster.getX();
        this.y = caster.getEyeY();
        this.z = caster.getZ();
    }
}
