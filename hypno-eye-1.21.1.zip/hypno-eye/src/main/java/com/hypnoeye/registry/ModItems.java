package com.hypnoeye.registry;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.item.HypnoEyeItem;
import com.hypnoeye.item.HypnoScreensItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HypnoEye.MODID);

    public static final DeferredItem<HypnoEyeItem> HYPNO_EYE = ITEMS.register("hypno_eye",
            () -> new HypnoEyeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<HypnoScreensItem> HYPNO_SCREENS = ITEMS.register("hypno_screens",
            () -> new HypnoScreensItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    private ModItems() {}
}
