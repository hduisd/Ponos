package com.hypnoeye.network;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.client.ClientPayloadHandler;
import com.hypnoeye.server.HypnosisLogic;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@EventBusSubscriber(modid = HypnoEye.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ModNetwork {
    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(HoldPayload.TYPE, HoldPayload.CODEC, ModNetwork::handleHold);
        registrar.playToClient(AnimPayload.TYPE, AnimPayload.CODEC, ClientPayloadHandler::handleAnim);
    }

    private static void handleHold(HoldPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                HypnosisLogic.onHold(player, payload.held());
            }
        });
    }

    private ModNetwork() {}
}
