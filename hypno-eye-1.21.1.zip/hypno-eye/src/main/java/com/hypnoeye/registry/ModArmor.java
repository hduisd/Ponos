package com.hypnoeye.registry;

import java.util.EnumMap;
import java.util.List;

import com.hypnoeye.HypnoEye;

import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Armor material of the Bean Beetle Mask. The worn texture is textures/models/armor/bug_mask_layer_1.png. */
public final class ModArmor {
    public static final DeferredRegister<ArmorMaterial> MATERIALS = DeferredRegister.create(Registries.ARMOR_MATERIAL, HypnoEye.MODID);

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> BUG_MASK = MATERIALS.register("bug_mask",
            () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                        map.put(ArmorItem.Type.BOOTS, 1);
                        map.put(ArmorItem.Type.LEGGINGS, 2);
                        map.put(ArmorItem.Type.CHESTPLATE, 3);
                        map.put(ArmorItem.Type.HELMET, 3);
                        map.put(ArmorItem.Type.BODY, 3);
                    }),
                    18,
                    SoundEvents.ARMOR_EQUIP_IRON,
                    () -> Ingredient.of(Items.GOLD_INGOT),
                    List.of(new ArmorMaterial.Layer(HypnoEye.id("bug_mask"))),
                    1.0F,
                    0.0F));

    private ModArmor() {}
}
