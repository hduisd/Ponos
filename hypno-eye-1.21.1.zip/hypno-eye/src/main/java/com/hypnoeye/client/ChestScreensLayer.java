package com.hypnoeye.client;

import java.util.Set;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws the Screens Vest: six small screens floating behind the shoulders, each connected to the back by a wire.
 * They sit "switched off" (dim) and play the pixel ring animation while the wearer channels the Hypno Eye.
 * Geometry is in model pixels (1/16 block), Y points down, the back of the body is +Z.
 */
public class ChestScreensLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    /** Entity types with a humanoid body this layer is attached to (the player is added separately). */
    public static final Set<EntityType<?>> WEARERS = Set.of(
            EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.SKELETON,
            EntityType.STRAY, EntityType.BOGGED, EntityType.WITHER_SKELETON);

    private static final ResourceLocation LENS = HypnoEye.id("textures/entity/hypno_lens.png");
    private static final int FRAMES = 12;

    // x, y, z, halfWidth, halfHeight, tilt(deg), phase
    private static final float[][] SCREENS = {
            // Fan around the head, like the reference: upper screen close to the head, big middle one further out, lower one outermost.
            {10.0F, -10.0F, 6.0F, 4.0F, 3.4F, -14.0F, 0.0F},
            {18.0F, -3.0F, 6.5F, 4.4F, 3.7F, 12.0F, 1.3F},
            {14.5F, 6.0F, 5.0F, 3.4F, 2.9F, -16.0F, 2.1F},
            {-10.0F, -10.0F, 6.0F, 3.8F, 3.2F, 16.0F, 3.0F},
            {-18.0F, -4.0F, 6.5F, 4.2F, 3.5F, -10.0F, 4.2F},
            {-14.5F, 5.0F, 5.0F, 3.2F, 2.7F, 18.0F, 5.1F}
    };

    public ChestScreensLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || entity.isBaby() || !entity.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.HYPNO_SCREENS.get())) {
            return;
        }
        float open = ClientAnimState.channelOpen(entity, partialTick); // the wearer's Hypno Eye channel drives the screens
        float bright = 0.28F + 0.72F * open;
        VertexConsumer quads = buffer.getBuffer(RenderType.entityTranslucentEmissive(LENS));
        PoseStack.Pose pose = poseStack.last();

        for (float[] sc : SCREENS) {
            float bob = Mth.sin(ageInTicks * 0.07F + sc[6]) * 0.9F;
            float cx = sc[0];
            float cy = sc[1] + bob;
            float cz = sc[2];

            int frame = open > 0.02F ? ((int) (ageInTicks + sc[6] * 3.0F)) % FRAMES : 0;
            float u0 = frame / (float) FRAMES;
            float u1 = (frame + 1) / (float) FRAMES;
            float rad = (sc[5] + Mth.sin(ageInTicks * 0.05F + sc[6]) * 3.0F) * Mth.DEG_TO_RAD;
            float c = Mth.cos(rad);
            float s = Mth.sin(rad);
            for (int i = 0; i < 4; i++) {
                float sx = (i < 2) ? -1.0F : 1.0F;
                float sy = (i == 0 || i == 3) ? -1.0F : 1.0F;
                float x = sx * sc[3];
                float y = sy * sc[4] * (1.0F + 0.10F * sx);   // not a perfect rectangle
                quads.addVertex(pose, (cx + x * c - y * s) / 16.0F, (cy + x * s + y * c) / 16.0F, cz / 16.0F)
                        .setColor(bright, bright, bright, 1.0F)
                        .setUv(sx < 0 ? u0 : u1, sy < 0 ? 0.0F : 1.0F)
                        .setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(LightTexture.FULL_BRIGHT)
                        .setNormal(pose, 0.0F, 0.0F, -1.0F);
            }
        }

        // Wires go in a second pass: requesting another buffer closes the previous one, so never interleave them.
        VertexConsumer wires = buffer.getBuffer(RenderType.lines());
        for (float[] sc : SCREENS) {
            float bob = Mth.sin(ageInTicks * 0.07F + sc[6]) * 0.9F;
            float side = Math.signum(sc[0]);
            wire(wires, pose, side * 2.0F, 3.0F, 2.6F, sc[0] - side * 1.5F, sc[1] + bob + 1.0F, sc[2]);
        }
    }

    /** A drooping cable (quadratic curve) from the back to a screen, drawn as thin dark lines. */
    private static void wire(VertexConsumer vc, PoseStack.Pose pose, float ax, float ay, float az, float bx, float by, float bz) {
        float mx = (ax + bx) * 0.5F;
        float my = (ay + by) * 0.5F + 6.0F; // sag
        float mz = (az + bz) * 0.5F + 2.0F;
        int n = 8;
        float px = ax;
        float py = ay;
        float pz = az;
        for (int k = 1; k <= n; k++) {
            float t = k / (float) n;
            float u = 1.0F - t;
            float x = u * u * ax + 2.0F * u * t * mx + t * t * bx;
            float y = u * u * ay + 2.0F * u * t * my + t * t * by;
            float z = u * u * az + 2.0F * u * t * mz + t * t * bz;
            float dx = x - px;
            float dy = y - py;
            float dz = z - pz;
            float len = Mth.sqrt(dx * dx + dy * dy + dz * dz);
            if (len > 1.0E-4F) {
                dx /= len;
                dy /= len;
                dz /= len;
                vc.addVertex(pose, px / 16.0F, py / 16.0F, pz / 16.0F).setColor(10, 10, 16, 255).setNormal(pose, dx, dy, dz);
                vc.addVertex(pose, x / 16.0F, y / 16.0F, z / 16.0F).setColor(10, 10, 16, 255).setNormal(pose, dx, dy, dz);
            }
            px = x;
            py = y;
            pz = z;
        }
    }
}
