#!/usr/bin/env python3
"""Generates all textures and sounds of the Hypno Eye mod (style: hot-pink eye, black rings, white zigzag pupil).
Run from the project root:  python3 tools/gen_assets.py   (needs Pillow + numpy + ffmpeg with libvorbis)"""
import math, random, subprocess, wave, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "hypnoeye")
PINK = (224, 0, 106)
DEEP = (150, 0, 80)
BLACK = (8, 0, 12)
WHITE = (255, 255, 255)
SS = 4  # supersampling


def out(*p):
    path = os.path.join(ROOT, *p)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


# ---------------------------------------------------------------- spiral (rotating iris), 128x128
def spiral(size=128):
    n = size * SS
    ys, xs = np.mgrid[0:n, 0:n]
    x = (xs + 0.5) / n * 2 - 1
    y = (ys + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    img = np.zeros((n, n, 4), dtype=np.float32)
    img[..., :3] = PINK
    # spiral band: 3 arms, black stripes
    v = (r * 3.2 - th / (2 * math.pi) * 3.0) % 1.0
    band = (v < 0.42) & (r > 0.34) & (r < 0.86)
    img[band, :3] = BLACK
    # solid black outer ring and inner ring around the pupil
    outer = (r > 0.88) & (r <= 1.0)
    inner = (r > 0.27) & (r < 0.34)
    img[outer, :3] = BLACK
    img[inner, :3] = BLACK
    # darker pink centre
    img[r < 0.27, :3] = DEEP
    img[..., 3] = np.where(r <= 1.0, 255, 0)
    im = Image.fromarray(img.astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)
    return im


# ---------------------------------------------------------------- zigzag pupil frames (4 frames strip)
def pupil_strip(fs=64, frames=4):
    rnd = random.Random(7)
    strip = Image.new("RGBA", (fs * frames, fs), (0, 0, 0, 0))
    ys = [0.08, 0.22, 0.34, 0.46, 0.56, 0.68, 0.80, 0.93]
    for f in range(frames):
        big = fs * SS
        mask = Image.new("L", (big, big), 0)
        d = ImageDraw.Draw(mask)
        pts = []
        for i, yy in enumerate(ys):
            amp = 0.0 if i in (0, len(ys) - 1) else rnd.uniform(0.10, 0.30) * (1 if i % 2 else -1)
            pts.append((big * (0.5 + amp * (0.6 if f % 2 else 1.0)), big * yy))
        d.line(pts, fill=255, width=int(big * 0.05), joint="curve")
        glow = mask.filter(ImageFilter.GaussianBlur(big * 0.035))
        glow = glow.point(lambda v: min(255, int(v * 1.6)))
        frame = Image.new("RGBA", (big, big), (255, 120, 190, 0))
        frame.putalpha(glow)
        core = Image.new("RGBA", (big, big), WHITE + (0,))
        core.putalpha(mask)
        frame = Image.alpha_composite(frame, core)
        frame = frame.resize((fs, fs), Image.LANCZOS)
        strip.paste(frame, (f * fs, 0))
    return strip


# ---------------------------------------------------------------- item icon 16x16 (hand-pixelled by formula)
def item_icon():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / 7.6, (y - cy) / 7.6
            r = math.hypot(dx, dy)
            # slightly eye-shaped (wider than tall)
            r = math.hypot(dx * 0.92, dy * 1.12)
            if r > 1.0:
                continue
            if r > 0.82:
                c = BLACK
            elif 0.46 < r < 0.62:
                c = BLACK
            elif r < 0.46:
                c = (190, 0, 92)
            else:
                c = PINK
            px[x, y] = c + (255,)
    # zigzag pupil
    zig = [(8, 2), (7, 4), (9, 6), (6, 8), (9, 10), (7, 11), (8, 13)]
    d = ImageDraw.Draw(im)
    for a, b in zip(zig, zig[1:]):
        d.line([a, b], fill=WHITE + (255,))
    # highlight pixel
    px[4, 4] = (255, 120, 190, 255)
    return im


def effect_icon():
    im = Image.new("RGBA", (18, 18), (0, 0, 0, 0))
    ic = item_icon().resize((16, 16), Image.NEAREST)
    im.paste(ic, (1, 1))
    return im


def particle_ring(size=16):
    n = size * 8
    ys, xs = np.mgrid[0:n, 0:n]
    x = (xs + 0.5) / n * 2 - 1
    y = (ys + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    img = np.zeros((n, n, 4), dtype=np.float32)
    img[..., :3] = PINK
    ring = (r > 0.55) & (r < 0.95)
    inner = (r > 0.22) & (r < 0.36)
    img[ring | inner, :3] = (20, 0, 24)
    # white glint on top of ring
    glint = ((r > 0.62) & (r < 0.88)) & (np.arctan2(y, x) > -2.4) & (np.arctan2(y, x) < -1.5)
    img[glint, :3] = WHITE
    img[..., 3] = np.where(((r > 0.55) & (r < 0.95)) | ((r > 0.22) & (r < 0.36)), 255, 0)
    return Image.fromarray(img.astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)


# ---------------------------------------------------------------- sounds
SR = 44100


def save_ogg(name, data):
    data = np.clip(data, -1, 1)
    wav = out("sounds", name + ".wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((data * 32000).astype("<i2").tobytes())
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5", out("sounds", name + ".ogg")], check=True)
    os.remove(wav)


def t_arr(sec):
    return np.linspace(0, sec, int(SR * sec), endpoint=False)


def env(t, a, d):
    e = np.minimum(t / a, 1.0) * np.exp(-t / d)
    return e


def echo(x, delay=0.11, gain=0.35, n=3):
    y = x.copy()
    for i in range(1, n + 1):
        s = int(SR * delay * i)
        y[s:] += x[:-s] * (gain ** i)
    return y


def snd_activate():
    sec = 1.5
    t = t_arr(sec)
    freq = 180 + 760 * (t / sec) ** 1.6
    phase = 2 * np.pi * np.cumsum(freq) / SR
    tone = np.sin(phase + 2.2 * np.sin(2 * np.pi * 9 * t))
    trem = 0.65 + 0.35 * np.sin(2 * np.pi * (6 + 10 * t / sec) * t)
    shimmer = np.sin(2 * np.pi * 2400 * t + 5 * np.sin(2 * np.pi * 31 * t)) * 0.12 * (t / sec)
    rnd = np.random.RandomState(3)
    noise = rnd.randn(len(t)) * 0.05 * np.sin(np.pi * t / sec)
    amp = np.minimum(t / 0.12, 1) * np.minimum((sec - t) / 0.35, 1)
    x = (tone * trem * 0.5 + shimmer + noise) * amp
    return echo(x, 0.13, 0.3, 3) * 0.7


def snd_success():
    sec = 1.1
    t = t_arr(sec)
    a = np.sin(2 * np.pi * 523.25 * t) * env(t, 0.005, 0.28)
    b = np.sin(2 * np.pi * 783.99 * t * (1 + 0.004 * np.sin(2 * np.pi * 7 * t))) * env(t, 0.005, 0.35)
    low = np.sin(2 * np.pi * 110 * t * (1 - 0.25 * t)) * env(t, 0.003, 0.2)
    rnd = np.random.RandomState(5)
    zap = rnd.randn(len(t)) * env(t, 0.001, 0.025) * 0.5
    zap = zap - np.concatenate([[0], zap[:-1]]) * 0.9  # high-pass-ish
    x = 0.45 * a + 0.35 * b + 0.5 * low + 0.6 * zap
    return echo(x, 0.09, 0.3, 3) * 0.75


def snd_end():
    sec = 0.95
    t = t_arr(sec)
    freq = 640 * np.exp(-3.2 * t / sec) + 70
    phase = 2 * np.pi * np.cumsum(freq) / SR
    x = np.sin(phase + 1.2 * np.sin(2 * np.pi * 5 * t)) * np.exp(-t / 0.4) * np.minimum(t / 0.02, 1)
    pop = np.sin(2 * np.pi * 90 * t) * env(t, 0.002, 0.05)
    return echo(0.55 * x + 0.5 * pop, 0.1, 0.25, 2) * 0.8


if __name__ == "__main__":
    spiral().save(out("textures", "entity", "hypno_spiral.png"))
    pupil_strip().save(out("textures", "entity", "hypno_pupil.png"))
    item_icon().save(out("textures", "item", "hypno_eye.png"))
    effect_icon().save(out("textures", "mob_effect", "hypnosis.png"))
    particle_ring().save(out("textures", "particle", "hypno_ring.png"))
    # the only sound (hypno_loop.ogg) is the user's own, cut from his video; it is not generated here
    print("assets generated")
