package com.hypnoeye.registry;

import com.hypnoeye.HypnoEye;
import com.hypnoeye.server.HypnosisEffect;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(BuiltInRegistries.MOB_EFFECT, HypnoEye.MODID);

    public static final DeferredHolder<MobEffect, HypnosisEffect> HYPNOSIS = EFFECTS.register("hypnosis", HypnosisEffect::new);

    private ModEffects() {}
}
