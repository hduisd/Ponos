package com.hypnoeye.server;

import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;

/** Who hypnotized the entity. Stored in the entity's persistent data, so it survives world reloads. */
public final class HypnoData {
    private static final String KEY = "hypnoeye_master";

    public static void setMaster(LivingEntity entity, UUID master) {
        entity.getPersistentData().putUUID(KEY, master);
    }

    public static UUID getMaster(LivingEntity entity) {
        CompoundTag tag = entity.getPersistentData();
        return tag.hasUUID(KEY) ? tag.getUUID(KEY) : null;
    }

    public static void clear(LivingEntity entity) {
        entity.getPersistentData().remove(KEY);
    }

    private HypnoData() {}
}
