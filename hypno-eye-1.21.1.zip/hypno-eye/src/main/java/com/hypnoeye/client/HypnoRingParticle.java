package com.hypnoeye.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Rotating pink/black ring that grows and fades. Used for the hypnosis beam and for the hit on the target. */
public class HypnoRingParticle extends TextureSheetParticle {
    protected HypnoRingParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z);
        this.pickSprite(sprites);
        this.lifetime = 14 + this.random.nextInt(6);
        this.gravity = 0.0F;
        this.hasPhysics = false;
        this.xd = 0.0;
        this.yd = 0.0;
        this.zd = 0.0;
        this.quadSize = 0.05F;
        this.roll = this.random.nextFloat() * ((float) Math.PI * 2.0F);
        this.oRoll = this.roll;
        this.alpha = 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        float p = (float) this.age / (float) this.lifetime;
        this.oRoll = this.roll;
        this.roll += 0.35F;
        this.quadSize = 0.06F + 0.20F * p;
        this.alpha = p < 0.2F ? p / 0.2F : 1.0F - (p - 0.2F) / 0.8F;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 15728880; // full bright
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xSpeed, double ySpeed, double zSpeed) {
            return new HypnoRingParticle(level, x, y, z, this.sprites);
        }
    }
}
