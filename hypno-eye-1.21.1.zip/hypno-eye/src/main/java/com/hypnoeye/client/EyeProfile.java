package com.hypnoeye.client;

/**
 * Where the eyes of one entity type are, in vanilla model pixels (1/16 block), relative to the head pivot,
 * Y pointing DOWN, the face looking towards -Z.
 *
 * @param pivotY    fallback neck pivot (model space) used when the model has no accessible head part
 * @param pivotZ    fallback neck pivot (model space)
 * @param eyeX      distance of each eye from the face centre
 * @param eyeY      eye height relative to the pivot (negative = up)
 * @param faceZ     Z of the front of the face, slightly in front of the skin (negative)
 * @param eyeSize   diameter of the hypnotic eye overlay
 * @param thirdY    unused (kept for compatibility)
 * @param thirdSize diameter of the Hypno Eye lens on the wearer's left eye (0 = do not draw it on this entity)
 */
public record EyeProfile(float pivotY, float pivotZ, float eyeX, float eyeY, float faceZ, float eyeSize, float thirdY, float thirdSize) {
}
